#include "tdat.h"
#include "string.h"
#include "rsrc_write.h"

// Area to build a tdat resource
unsigned int tdat_size;
unsigned char tdat_canvas[10240]; // 10 kib

// note that the tdat resource does not keep an item count at the top.

void tdat_init(void)
{
	tdat_size = 0;
	return;
}

void tdat_add_entry(string type, signed int id)
{
	for(int i = 0; i < 4; i++)
	{
		tdat_canvas[tdat_size] = type[i];
		tdat_size++;
	}
	
	tdat_canvas[tdat_size] = (id >> 8) & 0xFF;
	tdat_size++;
	tdat_canvas[tdat_size] = id & 0xFF;
	tdat_size++;
	tdat_canvas[tdat_size] = (id >> 8) & 0xFF;
	tdat_size++;
	tdat_canvas[tdat_size] = id & 0xFF;
	tdat_size++;

	for(int i = 0; i < 8; i++)
	{
		tdat_canvas[tdat_size] = 0x00;
		tdat_size++;
	}
	return;
}

void get_tdat_resource(unsigned char **resource_data, unsigned int *resource_data_size)
{
	*resource_data_size = tdat_size;
	*resource_data = tdat_canvas;
	return;
}

void store_tdat_resource(void)
{
	store_rsrc_data("tdat", 1, tdat_canvas, &tdat_size);
	return;
}