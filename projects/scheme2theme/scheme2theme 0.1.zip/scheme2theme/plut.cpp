#include "plut.h"
#include "rsrc_write.h"

// Area to build a plut resource
unsigned int plut_size;
unsigned char plut_canvas[10240]; // 10 kib

void plut_init(void)
{
	plut_canvas[0] = 0x00;
	plut_canvas[1] = 0x00; // Mac OS Classic Version
	plut_canvas[2] = 0x00;
	plut_canvas[3] = 0x08; // 8-bit
	plut_canvas[4] = 0x00;
	plut_canvas[5] = 0x2A; // Unknown, always 42
	plut_canvas[6] = 0x00; // Plut entry count
	plut_canvas[7] = 0x00;
	plut_size = 8;
	
	return;
}

void add_user_plut_entry(signed int ppat_id, unsigned int red, unsigned int green, unsigned int blue)
{
	plut_canvas[plut_size] = (ppat_id >> 8) & 0xFF;
	plut_size++;
	plut_canvas[plut_size] = ppat_id & 0xFF;
	plut_size++;
	plut_canvas[plut_size] = (red >> 8) & 0xFF;
	plut_size++;
	plut_canvas[plut_size] = red & 0xFF;
	plut_size++;
	plut_canvas[plut_size] = (green >> 8) & 0xFF;
	plut_size++;
	plut_canvas[plut_size] = green & 0xFF;
	plut_size++;
	plut_canvas[plut_size] = (blue >> 8) & 0xFF;
	plut_size++;
	plut_canvas[plut_size] = blue & 0xFF;
	plut_size++;
	
	// Update plut counter.
	unsigned int plut_count = (plut_canvas[6] << 8) | plut_canvas[7];
	plut_count++;
	plut_canvas[6] = (plut_count >> 8) & 0xFF;
	plut_canvas[7] = plut_count & 0xFF;
	
	return;
}

void get_plut_resource(unsigned char **resource_data, unsigned int *resource_data_size)
{
	*resource_data_size = plut_size;
	*resource_data = plut_canvas;
	return;
}

void store_plut_resource(void)
{	
	store_rsrc_data("plut", 387, plut_canvas, &plut_size);
	return;
}
