#ifndef CICN_H
#define CICN_H

#include <string>
using namespace std;

enum cicn_convert_error_t
{
	NO_CICN_ERROR = 0,
	CICN_NOT_FOUND = 1,
	CICN_PARSE_ERROR = 2
};

cicn_convert_error_t cicn_grow_box_convert(signed int cicn_id, signed int output_id);
cicn_convert_error_t cicn_window_frame_convert(signed int frame_id, signed int output_frame_id, signed int racing_stripe_id, signed int output_racing_stripe_id);

#endif