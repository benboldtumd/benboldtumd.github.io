#include <iostream>
#include <string>
#include <fstream>
using namespace std;

#include "rsrc_read.h"
#include "rsrc_write.h"
#include "widget_to_pixmap.h"
#include "tdat.h"
#include "cicn.h"
#include "system_clut.h"
#include "plut.h"

typedef struct
{
	unsigned int unpressed_id;
	unsigned int pressed_id;
	unsigned int pixmap_id;
	unsigned int repetitions;
} widget_conversion_data_t;

int main (int argc, char * const argv[]) {
/*	if(argc < 2)
	{
		cout << "Please supply the path to a Kaleidoscope Scheme as an argument.\n";
		return 0;
	}
	
	cout << argv[1] << endl;
	string filename = argv[1];
	filename.append("/rsrc");
	
	rsrc_read_init(filename.c_str());
*/
	rsrc_read_init("Onyx/rsrc");

	rsrc_write_init();
	tdat_init();
	plut_init();
	
	// Store system clut for icl8 conversion.
	make_system_clut();
	
	// Area to build a new resource
	unsigned int new_resource_data_size;
	unsigned char new_resource_data[10240]; // 10 kib
		
	// Convert window widget icons into pxm# format.
	widget_conversion_data_t widget_conversion_data[6];
	widget_conversion_data[0].unpressed_id = -14336; // Large Close
	widget_conversion_data[0].pressed_id   = -14333;
	widget_conversion_data[0].pixmap_id    = 200;
	widget_conversion_data[0].repetitions  = 1;
	widget_conversion_data[1].unpressed_id = -14335; // Large Collapse
	widget_conversion_data[1].pressed_id   = -14332;
	widget_conversion_data[1].pixmap_id    = 210;
	widget_conversion_data[1].repetitions  = 1;
	widget_conversion_data[2].unpressed_id = -14334; // Large Zoom
	widget_conversion_data[2].pressed_id   = -14331;
	widget_conversion_data[2].pixmap_id    = 220;
	widget_conversion_data[2].repetitions  = 3;
	widget_conversion_data[3].unpressed_id = -14320; // Small Close
	widget_conversion_data[3].pressed_id   = -14317;
	widget_conversion_data[3].pixmap_id    = 201;
	widget_conversion_data[3].repetitions  = 1;
	widget_conversion_data[4].unpressed_id = -14319; // Small Collapse
	widget_conversion_data[4].pressed_id   = -14316;
	widget_conversion_data[4].pixmap_id    = 211;
	widget_conversion_data[4].repetitions  = 1;
	widget_conversion_data[5].unpressed_id = -14318; // Small Zoom
	widget_conversion_data[5].pressed_id   = -14315;
	widget_conversion_data[5].pixmap_id    = 221;
	widget_conversion_data[5].repetitions  = 3;
	
	widget_convert_error_t widget_convert_error;
	for(int i = 0; i < 6; i++)
	{
		widget_convert_error = widget_convert(widget_conversion_data[i].unpressed_id, widget_conversion_data[i].pressed_id, widget_conversion_data[i].repetitions, new_resource_data, &new_resource_data_size);
		switch (widget_convert_error)
		{
			case MASK_NOT_FOUND:
				cout << "Error: ics# mask image was not found when building window widget id " << widget_conversion_data[i].pixmap_id << ".\n";
				break;
			case UNPRESSED_IMAGE_NOT_FOUND:
				cout << "Error: ics8 unpressed image was not found when building window widget id " << widget_conversion_data[i].pixmap_id << ".\n";
				break;
			case PRESSED_IMAGE_NOT_FOUND:
				cout << "Error: ics8 pressed image was not found when building window widget id " << widget_conversion_data[i].pixmap_id << ".\n";
				break;
			default:
				store_rsrc_data("pxm#", widget_conversion_data[i].pixmap_id, new_resource_data, &new_resource_data_size);
				tdat_add_entry("pxm#", widget_conversion_data[i].pixmap_id);  // All image resources must be referenced in the tdat resource.
		}
	}
	
	
	// Active Document Window
	cicn_grow_box_convert(-14330, 1282);
	cicn_window_frame_convert(-14332, 1280, -14331, 1281);
	
	// Copy over documet window racing stripes ppat and insert into plut.
	
	
	// Convert document window racing stripe endcaps from cicn (with mask) into pxm# format.
	
	
	// Build document window layo resources, enabled and disabled.
	
	// Store tdat resource:
	store_plut_resource();
	store_tdat_resource();
}
