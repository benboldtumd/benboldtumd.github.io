#ifndef PLUT_H
#define PLUT_H

void plut_init(void);
void add_user_plut_entry(signed int ppat_id, unsigned int red, unsigned int green, unsigned int blue);
void get_plut_resource(unsigned char **resource_data, unsigned int *resource_data_size);
void store_plut_resource(void);

#endif