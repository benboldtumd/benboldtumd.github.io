#include "cicn.h"
#include "rsrc_read.h"
#include "rsrc_write.h"
#include "tdat.h"
#include "plut.h"

#include <iostream>
using namespace std;

unsigned char* resource_data;
unsigned int resource_data_size;

unsigned char* output_data;
unsigned int output_data_size;

unsigned int image_row_bytes;
unsigned int image_row_count;
unsigned int image_bit_depth;
unsigned int mask_row_bytes;
unsigned int mask_row_count;
unsigned int one_bit_row_bytes;
unsigned int one_bit_row_count;

unsigned int image_width;

unsigned int color_table_start;
unsigned int color_table_end;

void extract_clut_resource(signed int id)
{
	// Find beginning of color table.
	color_table_start = 0x52 + (mask_row_bytes * image_row_count) + (one_bit_row_bytes * one_bit_row_count) + 6;
	color_table_end = color_table_start + 2 + ((resource_data[color_table_start] << 8 | resource_data[color_table_start+1]) + 1) * 8;
	
	output_data_size = color_table_end - color_table_start + 6;
	output_data = new unsigned char[output_data_size];
	
	for(int i = 0; i < 6; i++)
	{
		output_data[i] = 0;
	}
	for(int i = color_table_start; i < color_table_end; i++)
	{
		output_data[i - color_table_start + 6] = (unsigned int)resource_data[i];
	}
	
	store_rsrc_data("clut", id, output_data, &output_data_size);
	tdat_add_entry("clut", id);  // All image resources must be referenced in the tdat resource.
}

void build_pixmap_header(unsigned int mask_mode, unsigned int image_count, signed int clut_id)
{
	image_width = (image_row_bytes * 8) / image_bit_depth;

	output_data[0]  = 0x00, output_data[1] = 0x01; // Mac OS 8
	output_data[2]  = ((mask_mode >> 8) & 0xFF), output_data[3] = (mask_mode & 0xFF); // Mask Mode 1 = single, 0 = one for each image.
	output_data[4]  = 0x00, output_data[5] = 0x00; // Top Bound
	output_data[6]  = 0x00, output_data[7] = 0x00; // Left Bound
	output_data[8]  = ((image_row_count >> 8) & 0xFF), output_data[9] = (image_row_count & 0xFF); // Bottom Bound, aka height
	output_data[10] = ((image_width >> 8) & 0xFF), output_data[11] = (image_width & 0xFF); // Right Bound, aka width
	output_data[12] = 0x00, output_data[13] = (image_bit_depth & 0xFF); // Bit Depth
	output_data[14] = 0x00, output_data[15] = 0x08; // Pixel Type = Indexed
	output_data[16] = 0x00, output_data[17] = 0x00, output_data[18] = 0x00, output_data[19] = 0x00; // Unknown
	output_data[20] = ((clut_id >> 8) & 0xFF), output_data[21] = (clut_id & 0xFF); // clut resource ID matches pxm# ID for simplicity.
	output_data[22] = ((image_count >> 8) & 0xFF), output_data[23] = (image_count & 0xFF); // Image count
	
	output_data_size = 24;  // Update size for the above data.	
}

void store_opaque_mask(void)
{
	// Note that all image rows must be stored in multiples of 16 bits.
	for(int i = 0; i < mask_row_bytes * mask_row_count; i++)
	{
		output_data[output_data_size] = 0xFF;
		output_data_size++;
	}	
}

void convert_mask(void)
{
	// Note that all image rows must be stored in multiples of 16 bits.
	for(int i = 0; i < mask_row_bytes * mask_row_count; i++)
	{
		output_data[output_data_size] = (unsigned int)resource_data[0x52 + i];
		output_data_size++;
	}	
}

void clear_output_image(void)
{
	for(int i = 0; i < image_row_bytes * image_row_count; i++)
	{
		output_data[output_data_size + i] = 0x00;
	}
}

void clear_output_mask(void)
{
	for(int i = 0; i < mask_row_bytes * mask_row_count; i++)
	{
		output_data[output_data_size + i] = 0x00;
	}
}

// This function considers bit depth to copy an individual pixel.
void copy_pixel_to_output(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y)
{
	 // 1, 2, 4, 8 -> 8, 4, 2, 1
	#define PIXELS_PER_BYTE (8 / image_bit_depth)
	#define SOURCE_PIXEL (source_x + (source_y * image_width))
	#define DEST_PIXEL (dest_x + (dest_y * image_width))
	#define SOURCE_PIXEL_INDEX (color_table_end + (SOURCE_PIXEL / PIXELS_PER_BYTE))
	#define DEST_PIXEL_INDEX (output_data_size + (DEST_PIXEL / PIXELS_PER_BYTE))
	#define SOURCE_PIXEL_SHIFT ((8 - image_bit_depth) - ((SOURCE_PIXEL % PIXELS_PER_BYTE) * image_bit_depth))
	#define DEST_PIXEL_SHIFT ((8 - image_bit_depth) - ((DEST_PIXEL % PIXELS_PER_BYTE) * image_bit_depth))
	#define PIXEL_MASK ((1 << image_bit_depth) - 1)
	#define PIXEL_VALUE ((resource_data[SOURCE_PIXEL_INDEX] >> SOURCE_PIXEL_SHIFT ) & PIXEL_MASK)

	output_data[DEST_PIXEL_INDEX] &= ~(PIXEL_MASK << DEST_PIXEL_SHIFT);  // Turn off destination pixel first
	output_data[DEST_PIXEL_INDEX] |= (PIXEL_VALUE << DEST_PIXEL_SHIFT);  // 'Or' in the new pixel.
}

// This function considers bit depth to copy an individual pixel.
void copy_mask_pixel_to_output(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y)
{
	#define MASK_SOURCE_PIXEL (source_x + (source_y * image_width))
	#define MASK_DEST_PIXEL (dest_x + (dest_y * image_width))
	#define MASK_SOURCE_PIXEL_INDEX (0x52 + (MASK_SOURCE_PIXEL / 8))
	#define MASK_DEST_PIXEL_INDEX (output_data_size + (MASK_DEST_PIXEL / 8))
	#define MASK_SOURCE_PIXEL_SHIFT (7 - (MASK_SOURCE_PIXEL % 8))
	#define MASK_DEST_PIXEL_SHIFT (7 - (MASK_DEST_PIXEL % 8))
	#define MASK_PIXEL_VALUE ((resource_data[MASK_SOURCE_PIXEL_INDEX] >> MASK_SOURCE_PIXEL_SHIFT ) & 1)
	
	output_data[MASK_DEST_PIXEL_INDEX] &= ~(1 << MASK_DEST_PIXEL_SHIFT);  // Turn off destination pixel first
	output_data[MASK_DEST_PIXEL_INDEX] |= (MASK_PIXEL_VALUE << MASK_DEST_PIXEL_SHIFT);  // 'Or' in the new pixel.
}

void copy_rectangle_to_output(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y, unsigned int width, unsigned int height)
{
	for(int i = 0; i < width; i++)
	{
		for(int j = 0; j < height; j++)
		{
			copy_pixel_to_output(source_x + i, source_y + j, dest_x + i, dest_y + j);
		}
	}
}

void copy_mask_rectangle_to_output(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y, unsigned int width, unsigned int height)
{
	for(int i = 0; i < width; i++)
	{
		for(int j = 0; j < height; j++)
		{
			copy_mask_pixel_to_output(source_x + i, source_y + j, dest_x + i, dest_y + j);
		}
	}
}

void update_output_counter(void)
{
//	output_data_size += (image_row_bytes * image_row_count);
//	return;
	// 'pxm#' requires bytes per row must be even. (16-bit words)
	// 'cicn' allows row byte counts that are odd (8-bit words), so if they are odd, they must be padded.
	// This function reviews the newest output image before updatin gthe counter.
	if(0 != image_row_bytes % 2)
	{
		for(int i = 0; i < image_row_count; i++)
		{
			// Insert padded byte.
			output_data[output_data_size + (image_row_bytes * image_row_count) + image_row_count - (i*(image_row_bytes+1)) - 1] = 0x00;
			
			for(int j = 0; j < image_row_bytes; j++)
			{
				output_data[output_data_size + (image_row_bytes * image_row_count) + image_row_count - j - 1 - (i*(image_row_bytes+1)) - 1] =
				output_data[output_data_size + (image_row_bytes * image_row_count) - j - (i * image_row_bytes) - 1];
				// And let me tell you my head still isn't untwisted from that...
			}
		}
		output_data_size += (image_row_bytes * image_row_count) + image_row_count;
	}
	else
	{
		output_data_size += (image_row_bytes * image_row_count);
	}
}

void update_output_counter_mask(void)
{
	output_data_size += (mask_row_bytes * mask_row_count);
}

cicn_convert_error_t cicn_grow_box_convert(signed int cicn_id, signed int output_id)
{
	if(get_resource_data("cicn", cicn_id, &resource_data, &resource_data_size))
	{
		image_row_bytes = (resource_data[4] << 8 | resource_data[5]) & 0x1FFF;  // Use only bits 0 - 12
		image_row_count = (resource_data[10] << 8 | resource_data[11]);  // Height
		image_bit_depth = (resource_data[32] << 8 | resource_data[33]);
		mask_row_bytes = (resource_data[52] << 24 | resource_data[53] << 16 | resource_data[54] << 8 | resource_data[55]);
		mask_row_count = (resource_data[60] << 8 | resource_data[61]);
		one_bit_row_bytes = (resource_data[66] << 24 | resource_data[67] << 16 | resource_data[68] << 8 | resource_data[69]);
		one_bit_row_count = (resource_data[74] << 8 | resource_data[75]);
	}
	else return CICN_NOT_FOUND;
	
	// BUILD clut RESOURCE FROM cicn.
	extract_clut_resource(output_id);
	
	// BUILD pxm# RESOURCE FROM cicn.
	
	// Build pxm# Header.	
	build_pixmap_header(1, 1, output_id); // Single Mask, 1 image, clut resource ID.
	
	// Build pxm# mask (totally opaque)
	convert_mask();
	
	// Build image 0 in pxm#: outer corners
	clear_output_image();
	copy_rectangle_to_output(0, 0, 0, 0, image_width, image_row_count);  // copy entire image.
	update_output_counter();
	
	store_rsrc_data("pxm#", output_id, output_data, &output_data_size);
	tdat_add_entry("pxm#", output_id);  // All image resources must be referenced in the tdat resource.
	
	return NO_CICN_ERROR;
}

cicn_convert_error_t cicn_window_frame_convert(signed int frame_id, signed int output_frame_id, signed int racing_stripe_id, signed int output_racing_stripe_id)
{	
	if(get_resource_data("cicn", frame_id, &resource_data, &resource_data_size))
	{
		image_row_bytes = (resource_data[4] << 8 | resource_data[5]) & 0x1FFF;  // Use only bits 0 - 12
		image_row_count = (resource_data[10] << 8 | resource_data[11]);  // Height
		image_bit_depth = (resource_data[32] << 8 | resource_data[33]);
		mask_row_bytes = (resource_data[52] << 24 | resource_data[53] << 16 | resource_data[54] << 8 | resource_data[55]);
		mask_row_count = (resource_data[60] << 8 | resource_data[61]);
		one_bit_row_bytes = (resource_data[66] << 24 | resource_data[67] << 16 | resource_data[68] << 8 | resource_data[69]);
		one_bit_row_count = (resource_data[74] << 8 | resource_data[75]);
	}
	else return CICN_NOT_FOUND;
		
	// BUILD clut RESOURCE FROM cicn.
	extract_clut_resource(output_frame_id);

	// BUILD pxm# RESOURCE FROM cicn.
	
	// Build pxm# Header.	
	build_pixmap_header(1, 6, output_frame_id); // Single Mask, 6 images, clut resource ID.
	
	// Build pxm# mask (totally opaque)
	store_opaque_mask();
	
	// Build image 0 in pxm#: outer corners
	clear_output_image();
	copy_rectangle_to_output(0, 0, 0, 0, 4, 4);  // Top Left
	copy_rectangle_to_output(12, 0, 12, 0, 4, 4);  // Top Right
	copy_rectangle_to_output(0, 10, 0, 10, 6, 6);  // Bottom Left
	copy_rectangle_to_output(10, 10, 10, 10, 6, 6);  // Bottom Right
	update_output_counter();
	
	// Build image 1 in pxm#: outer top and bottom
	clear_output_image();
	for(int i = 0; i < 16; i++)
	{
		copy_rectangle_to_output(6, 0, i, 0, 1, 3);  // Top Edge
		copy_rectangle_to_output(6, 10, i, 10, 1, 6);  // Bottom Edge
	}
	update_output_counter();

	// Build image 2 in pxm#: outer left and right
	clear_output_image();
	for(int i = 0; i < 16; i++)
	{
		copy_rectangle_to_output(0, 6, 0, i, 6, 1);  // Left Edge
		copy_rectangle_to_output(10, 6, 10, i, 6, 1);  // Right Edge
	}
	update_output_counter();
	
	// Build image 3 in pxm#: inner corners and inner top edge
	clear_output_image();
	copy_rectangle_to_output(4, 3, 0, 0, 2, 3);  // Left Inner Corner
	copy_rectangle_to_output(10, 3, 14, 0, 2, 3);  // Right Inner Corner
	for(int i = 0; i < 16; i++)  // Inner Top Edge (stored on bottom of image)
	{
		copy_rectangle_to_output(6, 4, i, 14, 1, 2);
	}
	update_output_counter();

	// Build image 4 in pxm#: Title Bar Color
	for(int i = 0; i < 16; i++)
	{
		for(int j = 0; j < 16; j++)
		{
			copy_pixel_to_output(6, 3, i, j);
		}
	}
	update_output_counter();

	// Build image 5 in pxm#: Shadow Color
	for(int i = 0; i < 16; i++)
	{
		for(int j = 0; j < 16; j++)
		{
			copy_pixel_to_output(0, 0, i, j);
		}
	}
	update_output_counter();
	
	store_rsrc_data("pxm#", output_frame_id, output_data, &output_data_size);
	tdat_add_entry("pxm#", output_frame_id);  // All image resources must be referenced in the tdat resource.

	// Build racing stripes into new pxm# resource.
	if(get_resource_data("cicn", racing_stripe_id, &resource_data, &resource_data_size))
	{
		image_row_bytes = (resource_data[4] << 8 | resource_data[5]) & 0x1FFF;  // Use only bits 0 - 12
		image_row_count = (resource_data[10] << 8 | resource_data[11]);  // Height
		image_bit_depth = (resource_data[32] << 8 | resource_data[33]);
		mask_row_bytes = (resource_data[52] << 24 | resource_data[53] << 16 | resource_data[54] << 8 | resource_data[55]);
		mask_row_count = (resource_data[60] << 8 | resource_data[61]);
		one_bit_row_bytes = (resource_data[66] << 24 | resource_data[67] << 16 | resource_data[68] << 8 | resource_data[69]);
		one_bit_row_count = (resource_data[74] << 8 | resource_data[75]);
	}
	else return CICN_NOT_FOUND;
	
	// BUILD clut RESOURCE FROM cicn.
	extract_clut_resource(output_racing_stripe_id);
	
	// BUILD pxm# RESOURCE FROM cicn.
	
	// Build pxm# Header.	
	build_pixmap_header(0, 3, output_racing_stripe_id); // Separate Masks, 3 images, clut resource ID.
	
	// Copy Masks.
	clear_output_mask();
	copy_mask_rectangle_to_output(0, 0, 0, 0, 8, 13);  // Left cap
	update_output_counter_mask();
	
	clear_output_mask();
	copy_mask_rectangle_to_output(9, 0, 9, 0, 7, 13);  // Right cap
	update_output_counter_mask();
	
	clear_output_mask();
	for(int i = 0; i < 16; i++)
	{
		copy_mask_rectangle_to_output(8, 0, i, 0, 1, 13);  // Fill
	}
	update_output_counter_mask();
	
	clear_output_image();
	copy_rectangle_to_output(0, 0, 0, 0, 8, 13);
	update_output_counter();
	
	clear_output_image();
	copy_rectangle_to_output(9, 0, 9, 0, 7, 13);
	update_output_counter();
	
	clear_output_image();
	for(int i = 0; i < 16; i++)
	{
		copy_rectangle_to_output(8, 0, i, 0, 1, 13);  // Fill
	}
	update_output_counter();
	
	store_rsrc_data("pxm#", output_racing_stripe_id, output_data, &output_data_size);
	tdat_add_entry("pxm#", output_racing_stripe_id);  // All image resources must be referenced in the tdat resource.	

	// Check for racing stripe PPAT.
	if(get_resource_data("ppat", racing_stripe_id, &resource_data, &resource_data_size))
	{
		add_user_plut_entry(output_racing_stripe_id, 0xFFFF, 0xFFFF, 0xFFFF);
		store_rsrc_data("ppat", output_racing_stripe_id, resource_data, &resource_data_size);
		tdat_add_entry("ppat", output_racing_stripe_id);  // All image resources must be referenced in the tdat resource.	
	}
	else
	{
		add_user_plut_entry(0, 0xFFFF, 0xFFFF, 0xFFFF);
	}
	
	return NO_CICN_ERROR;
}