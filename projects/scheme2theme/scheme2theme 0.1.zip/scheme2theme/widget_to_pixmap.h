#ifndef WIDGET_TO_PIXMAP_H
#define WIDGET_TO_PIXMAP_H

#include <string>
using namespace std;

enum widget_convert_error_t
{
	NO_ERROR = 0,
	MASK_NOT_FOUND = 1,
	UNPRESSED_IMAGE_NOT_FOUND = 2,
	PRESSED_IMAGE_NOT_FOUND = 3
};

widget_convert_error_t widget_convert(signed int unpressed_id, signed int pressed_id, unsigned int repetitions, unsigned char *pixmap_data, unsigned int *pixmap_size);

#endif