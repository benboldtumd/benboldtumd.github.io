#ifndef PLUT_H
#define PLUT_H

void plut_init(void);
unsigned int add_user_plut_entry(signed int ppat_id, unsigned int red, unsigned int green, unsigned int blue);
void modify_required_plut(unsigned int plut_index, signed int ppat_id, unsigned int red, unsigned int green, unsigned int blue);
void get_user_plut_resource(unsigned char **resource_data, unsigned int *resource_data_size);
void store_user_plut_resource(void);
void get_required_plut_resource(unsigned char **resource_data, unsigned int *resource_data_size);
void store_required_plut_resource(void);

#endif