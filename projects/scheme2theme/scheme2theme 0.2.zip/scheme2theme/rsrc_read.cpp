#include "rsrc_read.h"

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

typedef struct
{
	unsigned int id;
	unsigned int name_length;
	unsigned char* name;
	unsigned char attributes;
	unsigned int name_offset;
	unsigned int data_offset;
	unsigned int data_length;
	unsigned char* data;
} resource_item_t;

typedef struct
{
	unsigned int type;  // store 4-byte ascii directly into unsigned int.
	unsigned int type_list_to_reference_list_offset;
	unsigned int resource_item_count;
	resource_item_t* resource_item;
} resource_type_t;

typedef struct
{
	string name;
	unsigned int attributes;
	
	unsigned int resource_data_start;
	unsigned int resource_map_start;
	unsigned int resource_data_length;
	unsigned int resource_map_length;
	
	unsigned int resource_map_to_type_list_offset;
	unsigned int resource_map_to_name_list_offset;
	
	unsigned int resource_type_count;
	resource_type_t* resource_type;
} resource_file_t;

static struct
{
	resource_file_t* resource_file;
} rsrc;

/******************************************************************
 * Init Function
 *
 * Initializes the rsrc module by parsing a resource file into
 * memory.
 ******************************************************************/
int rsrc_read_init(const char* filename) {
		
	rsrc.resource_file = new resource_file_t[1];  // Consider only 1 resource file at this point.
		
	ifstream input_file;
	input_file.open(filename);
	
	if(!input_file.is_open()) {
		cout << "Could not open input Kaleidoscope Scheme file.\n\n";
		return 1;
	}
	
	rsrc.resource_file[0].resource_data_start  = ( (input_file.get() << 24) | (input_file.get() << 16) | (input_file.get() << 8) | input_file.get() );
	rsrc.resource_file[0].resource_map_start   = ( (input_file.get() << 24) | (input_file.get() << 16) | (input_file.get() << 8) | input_file.get() );
	rsrc.resource_file[0].resource_data_length = ( (input_file.get() << 24) | (input_file.get() << 16) | (input_file.get() << 8) | input_file.get() );
	rsrc.resource_file[0].resource_map_length  = ( (input_file.get() << 24) | (input_file.get() << 16) | (input_file.get() << 8) | input_file.get() );
	
	cout << "Resource Data Start:  0x" << hex << rsrc.resource_file[0].resource_data_start << endl;
	cout << "Resource Map Start:   0x" << hex << rsrc.resource_file[0].resource_map_start << endl;
	cout << "Resource Data Length: 0x" << hex << rsrc.resource_file[0].resource_data_length << endl;
	cout << "Resource Map Length:  0x" << hex << rsrc.resource_file[0].resource_map_length << endl;
	
	// Seek to resource map, skipping reserved bytes.
	input_file.seekg(rsrc.resource_file[0].resource_map_start + 22, ios::beg);
	
	// Read resource file info.
	rsrc.resource_file[0].attributes = (input_file.get() << 8) | input_file.get(); // 2 bytes.
	rsrc.resource_file[0].resource_map_to_type_list_offset = (input_file.get() << 8) | input_file.get(); // 2 bytes.
	//cout << "Type List Offset:     0x" << hex << rsrc.resource_file[0].resource_map_to_type_list_offset << "\n\n";
	rsrc.resource_file[0].resource_map_to_name_list_offset = (input_file.get() << 8) | input_file.get(); // 2 bytes.
	
	// Read number of resource types.
	rsrc.resource_file[0].resource_type_count = ((input_file.get() << 8) | input_file.get()) + 1;
	//cout << "Number of resource types:  " << dec << rsrc.resource_file[0].resource_type_count << endl;
	
	// Reserve memory for those resource types.
	rsrc.resource_file[0].resource_type = new resource_type_t[rsrc.resource_file[0].resource_type_count];
	
	// Record type names and item counts for each resource type.
	for(int i = 0; i < rsrc.resource_file[0].resource_type_count; i++)
	{
		// Do an absolute seek each time through.
		input_file.seekg(rsrc.resource_file[0].resource_map_start + rsrc.resource_file[0].resource_map_to_type_list_offset + 2 + (i * 8), ios::beg);  // Seek to resource type count.
		rsrc.resource_file[0].resource_type[i].type = ( (input_file.get() << 24) | (input_file.get() << 16) | (input_file.get() << 8) | input_file.get() );
		
		//cout << "Type: ";
		for(int j = 0; j < 4; j++)
		{
			//cout << (char)((rsrc.resource_file[0].resource_type[i].type >> (8*(3-j))) & 0xFF);
		}
		//cout << "\n";
		
		rsrc.resource_file[0].resource_type[i].resource_item_count = ((input_file.get() << 8) | input_file.get()) + 1;
		//cout << "\tquantity: " << dec << rsrc.resource_file[0].resource_type[i].resource_item_count << "\n";
		rsrc.resource_file[0].resource_type[i].type_list_to_reference_list_offset = ((input_file.get() << 8) | input_file.get());
		//cout << "\treference list offset: 0x" << hex << rsrc.resource_file[0].resource_type[i].type_list_to_reference_list_offset << "\n\n";
		// Reserve memory for each resource.
		rsrc.resource_file[0].resource_type[i].resource_item = new resource_item_t[rsrc.resource_file[0].resource_type[i].resource_item_count];
		// Fill in resource information.
		
		for(int j = 0; j < rsrc.resource_file[0].resource_type[i].resource_item_count; j++)
		{
			input_file.seekg(rsrc.resource_file[0].resource_map_start + rsrc.resource_file[0].resource_map_to_type_list_offset + rsrc.resource_file[0].resource_type[i].type_list_to_reference_list_offset + (12 * j), ios::beg);  // Seek to resource type count.

			rsrc.resource_file[0].resource_type[i].resource_item[j].id = ((input_file.get() << 8) | input_file.get());
			//cout << "\tID: " << dec << rsrc.resource_file[0].resource_type[i].resource_item[j].id << "\n";
			rsrc.resource_file[0].resource_type[i].resource_item[j].name_offset = ((input_file.get() << 8) | input_file.get());			
			rsrc.resource_file[0].resource_type[i].resource_item[j].attributes = input_file.get();
			rsrc.resource_file[0].resource_type[i].resource_item[j].data_offset = ((input_file.get() << 16) | (input_file.get() << 8) | input_file.get());

			if(rsrc.resource_file[0].resource_type[i].resource_item[j].name_offset != 65535) // Check if ths resource has a name.
			{
				// Fetch Name
				input_file.seekg(
								 rsrc.resource_file[0].resource_map_start +
								 rsrc.resource_file[0].resource_map_to_name_list_offset +
								 rsrc.resource_file[0].resource_type[i].resource_item[j].name_offset,
								 ios::beg
								 );
				rsrc.resource_file[0].resource_type[i].resource_item[j].name_length = input_file.get();
				//cout << "\t\tName Length: " << rsrc.resource_file[0].resource_type[i].resource_item[j].name_length << "\n";
				rsrc.resource_file[0].resource_type[i].resource_item[j].name = new unsigned char[rsrc.resource_file[0].resource_type[i].resource_item[j].name_length + 1];
				//cout << "\t\tName: ";
				for(int k = 0; k < rsrc.resource_file[0].resource_type[i].resource_item[j].name_length; k++)
				{
					rsrc.resource_file[0].resource_type[i].resource_item[j].name[k] = input_file.get();
					//cout << (char)rsrc.resource_file[0].resource_type[i].resource_item[j].name[k];
				}
				rsrc.resource_file[0].resource_type[i].resource_item[j].name[rsrc.resource_file[0].resource_type[i].resource_item[j].name_length] = 0; // Null character on the end.
				//cout << "\n";
			}
			else
			{
				rsrc.resource_file[0].resource_type[i].resource_item[j].name_length = 0;
				rsrc.resource_file[0].resource_type[i].resource_item[j].name = new unsigned char[1];
				rsrc.resource_file[0].resource_type[i].resource_item[j].name[1] = 0; // Null character.
				//cout << "\t\tNo name.\n";
			}
			
			// Fetch Data
			input_file.seekg(
							 rsrc.resource_file[0].resource_data_start +
							 rsrc.resource_file[0].resource_type[i].resource_item[j].data_offset,
							 ios::beg
							 );
			rsrc.resource_file[0].resource_type[i].resource_item[j].data_length = (input_file.get() << 24) | (input_file.get() << 16) | (input_file.get() << 8) | input_file.get();
			rsrc.resource_file[0].resource_type[i].resource_item[j].data = new unsigned char[rsrc.resource_file[0].resource_type[i].resource_item[j].data_length];
			for(int k = 0; k < rsrc.resource_file[0].resource_type[i].resource_item[j].data_length; k++)
			{
				rsrc.resource_file[0].resource_type[i].resource_item[j].data[k] = input_file.get();
			}
		}
	}
	return 0;
}

unsigned int resource_type_to_int(string resource_type_string)
{
	if(resource_type_string.length() >= 4)
	{
		return (resource_type_string[0] << 24) | (resource_type_string[1] << 16) | (resource_type_string[2] << 8) | resource_type_string[3];
	}
	else return 0;
}

/******************************************************************
* Get Resource Data Function
*
* Returns pointers to resource data and size for the requested
* resource.  Data is not necessarily in any particular order
* according to indexes, so brute force searches are used.
*
* Returns true if resource was found, false if not.
******************************************************************/
bool get_resource_data(string resource_type_string, signed int resource_id, unsigned char **resource_data, unsigned int *resource_data_size)
{
	unsigned int resource_type = resource_type_to_int(resource_type_string);
	if(resource_id < 0)
	{
		resource_id += 65536;  // I'm not going to use signed numbers if it isn't necessary.
	}
	
	bool resource_found = false;
	unsigned int resource_type_index;
	for(resource_type_index = 0; resource_type_index < rsrc.resource_file[0].resource_type_count && false == resource_found; resource_type_index++)
	{
		if(rsrc.resource_file[0].resource_type[resource_type_index].type == resource_type)
		{
			resource_found = true;
		}
	}
	
	if(false == resource_found)
	{
		cout << "No resources of type '" << resource_type_string << "' were found when searching for '" << resource_type_string << "' ID# " << dec << (signed short int)resource_id << " in get_resource_data().\n";
		return false;
	}
	
	resource_type_index--;
	//cout << "Resource type was index " << dec << resource_type_index << "\n";
	
	resource_found = false;
	unsigned int resource_id_index;
	for(resource_id_index = 0; resource_id_index < rsrc.resource_file[0].resource_type[resource_type_index].resource_item_count && false == resource_found; resource_id_index++)
	{
		if(resource_id == rsrc.resource_file[0].resource_type[resource_type_index].resource_item[resource_id_index].id)
		{
			resource_found = true;
		}
	}
	
	if(false == resource_found)
	{
		cout << "Resource '" << resource_type_string << "' ID# " << dec << (signed short int)resource_id << " was not found in get_resource_data().\n";
		return false;
	}
	
	resource_id_index--;
	//cout << "Resource id was index " << dec << resource_id_index << "\n";
	
	*resource_data_size = rsrc.resource_file[0].resource_type[resource_type_index].resource_item[resource_id_index].data_length;
	*resource_data = rsrc.resource_file[0].resource_type[resource_type_index].resource_item[resource_id_index].data;
	
	return true;
}

bool resource_exists(string resource_type_string, signed int resource_id)
{
	unsigned int resource_type = resource_type_to_int(resource_type_string);
	if(resource_id < 0)
	{
		cout << resource_id << endl;
		resource_id += 65536;  // I'm not going to use signed numbers if it isn't necessary.
		cout << resource_id << endl;
	}
	
	// Resource types and IDs are not necessarily in any particular order, so brute force search is necessary.
	for(int i = 0; i < rsrc.resource_file[0].resource_type_count; i++)
	{
		if(rsrc.resource_file[0].resource_type[i].type == resource_type)
		{
			// Successfully found the resource type.  Now search for the ID.
			for(int j = 0; j < rsrc.resource_file[0].resource_type[i].resource_item_count; j++)
			{
				if(resource_id == rsrc.resource_file[0].resource_type[i].resource_item[j].id)
				{
					return true;
				}
			}
			return false;			
		}
	}
	return false;
}
