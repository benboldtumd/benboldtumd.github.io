#ifndef TDAT_H
#define TDAT_H

#include <string>
using namespace std;

void tdat_init(void);
void tdat_add_entry(string type, signed int id);
void get_tdat_resource(unsigned char **resource_data, unsigned int *resource_data_size);
void store_tdat_resource(void);

#endif