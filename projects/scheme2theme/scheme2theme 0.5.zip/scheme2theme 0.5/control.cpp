#include "control.h"
#include "cinf.h"
#include "cicn.h"
#include "layo.h"

#include <iostream>
using namespace std;

#define LARGE_TAB_HEIGHT 25
#define LARGE_REAR_TAB_HEIGHT 21

cinf_result_t cinf_result;	
layo_coordinate_t coordinate[12];

layo_item_t inactive_push_button;
layo_item_t active_push_button;
layo_item_t pressed_push_button;
layo_item_t push_button_text;

layo_item_t off_bevel_button;
layo_item_t on_bevel_button;
layo_item_t mixed_bevel_button;
layo_item_t off_pressed_bevel_button;
layo_item_t on_pressed_bevel_button;
layo_item_t mixed_pressed_bevel_button;
layo_item_t off_disabled_bevel_button;
layo_item_t on_disabled_bevel_button;
layo_item_t mixed_disabled_bevel_button;
layo_item_t bevel_button_text;

layo_item_t inactive_tab_pane;
layo_item_t active_tab_pane;

layo_item_t front_tab;
layo_item_t front_disabled_tab;
layo_item_t rear_tab;
layo_item_t rear_disabled_tab;
layo_item_t pressed_tab;
layo_item_t tab_text;

void control_init(void)
{
	// *** Push Button ***
	inactive_push_button.visible_only_if_bitfield = LAYO_FLAG_INACTIVE;
	inactive_push_button.invisible_if_bitfield = LAYO_FLAG_PRESSED;
	inactive_push_button.attribute_bitfield = LAYO_ATTR_VISIBLE;
	inactive_push_button.image_ref.resource_type = "pxm#";

	active_push_button.visible_only_if_bitfield = 0;
	active_push_button.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_PRESSED;
	active_push_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	active_push_button.image_ref.resource_type = "pxm#";
	
	pressed_push_button.visible_only_if_bitfield = LAYO_FLAG_PRESSED;
	pressed_push_button.invisible_if_bitfield = LAYO_FLAG_INACTIVE;
	pressed_push_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	pressed_push_button.image_ref.resource_type = "pxm#";

	push_button_text.visible_only_if_bitfield = 0;
	push_button_text.invisible_if_bitfield = 0;
	push_button_text.attribute_bitfield = LAYO_ATTR_TITLE_BAR | LAYO_ATTR_VISIBLE;
	push_button_text.image_ref.resource_type = "NULL";
	
	// *** Bevel Button ***
	// Off
	off_bevel_button.visible_only_if_bitfield = 0;
	off_bevel_button.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_ON | LAYO_FLAG_MIXED | LAYO_FLAG_PRESSED;
	off_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	off_bevel_button.image_ref.resource_type = "pxm#";	
	
	// On
	on_bevel_button.visible_only_if_bitfield = LAYO_FLAG_ON;
	on_bevel_button.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_MIXED | LAYO_FLAG_PRESSED;
	on_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	on_bevel_button.image_ref.resource_type = "pxm#";	
	
	// Mixed
	mixed_bevel_button.visible_only_if_bitfield = LAYO_FLAG_MIXED;
	mixed_bevel_button.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_ON | LAYO_FLAG_PRESSED;
	mixed_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	mixed_bevel_button.image_ref.resource_type = "pxm#";	
	
	// Off Pressed
	off_pressed_bevel_button.visible_only_if_bitfield = LAYO_FLAG_PRESSED;
	off_pressed_bevel_button.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_ON | LAYO_FLAG_MIXED;
	off_pressed_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	off_pressed_bevel_button.image_ref.resource_type = "pxm#";	
	
	// On Pressed
	on_pressed_bevel_button.visible_only_if_bitfield = LAYO_FLAG_ON | LAYO_FLAG_PRESSED;
	on_pressed_bevel_button.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_MIXED;
	on_pressed_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	on_pressed_bevel_button.image_ref.resource_type = "pxm#";	
	
	// Mixed Pressed
	mixed_pressed_bevel_button.visible_only_if_bitfield = LAYO_FLAG_MIXED | LAYO_FLAG_PRESSED;
	mixed_pressed_bevel_button.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_ON;
	mixed_pressed_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	mixed_pressed_bevel_button.image_ref.resource_type = "pxm#";	
	
	// Off Disabled
	off_disabled_bevel_button.visible_only_if_bitfield = LAYO_FLAG_INACTIVE;
	off_disabled_bevel_button.invisible_if_bitfield = LAYO_FLAG_ON | LAYO_FLAG_MIXED | LAYO_FLAG_PRESSED;
	off_disabled_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	off_disabled_bevel_button.image_ref.resource_type = "pxm#";	
	
	// On Disabled
	on_disabled_bevel_button.visible_only_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_ON;
	on_disabled_bevel_button.invisible_if_bitfield = LAYO_FLAG_MIXED | LAYO_FLAG_PRESSED;
	on_disabled_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	on_disabled_bevel_button.image_ref.resource_type = "pxm#";
	
	// Mixed Disabled
	mixed_disabled_bevel_button.visible_only_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_MIXED;
	mixed_disabled_bevel_button.invisible_if_bitfield = LAYO_FLAG_ON | LAYO_FLAG_PRESSED;
	mixed_disabled_bevel_button.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CLICK_ACTION;
	mixed_disabled_bevel_button.image_ref.resource_type = "pxm#";	

	// Text
	bevel_button_text.visible_only_if_bitfield = 0;
	bevel_button_text.invisible_if_bitfield = 0;
	bevel_button_text.attribute_bitfield = LAYO_ATTR_TITLE_BAR | LAYO_ATTR_VISIBLE;
	bevel_button_text.image_ref.resource_type = "NULL";
	
	// *** Tab Pane ***
	inactive_tab_pane.visible_only_if_bitfield = LAYO_FLAG_DISABLED;
	inactive_tab_pane.invisible_if_bitfield = 0;
	inactive_tab_pane.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CONTENT_AREA | LAYO_ATTR_TAB_PANE_CONTENT;
	inactive_tab_pane.image_ref.resource_type = "pxm#";
	
	active_tab_pane.visible_only_if_bitfield = 0;
	active_tab_pane.invisible_if_bitfield = LAYO_FLAG_DISABLED;
	active_tab_pane.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CONTENT_AREA | LAYO_ATTR_TAB_PANE_CONTENT;
	active_tab_pane.image_ref.resource_type = "pxm#";
	
	// *** Tabs ***	
	front_tab.visible_only_if_bitfield = LAYO_FLAG_INACTIVE;
	front_tab.invisible_if_bitfield = LAYO_FLAG_DISABLED | LAYO_FLAG_PRESSED;
	front_tab.attribute_bitfield = LAYO_ATTR_VISIBLE;
	front_tab.image_ref.resource_type = "pxm#";
	
	front_disabled_tab.visible_only_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_DISABLED;
	front_disabled_tab.invisible_if_bitfield = LAYO_FLAG_PRESSED;
	front_disabled_tab.attribute_bitfield = LAYO_ATTR_VISIBLE;
	front_disabled_tab.image_ref.resource_type = "pxm#";
	
	rear_tab.visible_only_if_bitfield = 0;
	rear_tab.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_DISABLED | LAYO_FLAG_PRESSED;
	rear_tab.attribute_bitfield = LAYO_ATTR_VISIBLE;
	rear_tab.image_ref.resource_type = "pxm#";
	
	rear_disabled_tab.visible_only_if_bitfield = LAYO_FLAG_DISABLED;
	rear_disabled_tab.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_PRESSED;
	rear_disabled_tab.attribute_bitfield = LAYO_ATTR_VISIBLE;
	rear_disabled_tab.image_ref.resource_type = "pxm#";
	
	pressed_tab.visible_only_if_bitfield = LAYO_FLAG_PRESSED;
	pressed_tab.invisible_if_bitfield = LAYO_FLAG_INACTIVE | LAYO_FLAG_DISABLED;
	pressed_tab.attribute_bitfield = LAYO_ATTR_VISIBLE;
	pressed_tab.image_ref.resource_type = "pxm#";

	tab_text.visible_only_if_bitfield = 0;
	tab_text.invisible_if_bitfield = 0;
	tab_text.attribute_bitfield = LAYO_ATTR_VISIBLE | LAYO_ATTR_CONTENT_AREA;
	tab_text.image_ref.resource_type = "NULL";
	
	return;
}

void control_parse_h_slider_thumb(signed int cicn_id, signed int pxm_id)
{
	unsigned int thumb_width = cicn_predict_width(cicn_id);
	unsigned int thumb_height = cicn_predict_height(cicn_id) / 4;
	cicn_load_cicn( cicn_id, thumb_width, thumb_height );
	
	cicn_copy_image_and_mask_rectangle(0, 0 * thumb_height, 0, 0, thumb_width, thumb_height);
	add_new_pxm_index();
	cicn_copy_image_and_mask_rectangle(0, 1 * thumb_height, 0, 0, thumb_width, thumb_height);
	add_new_pxm_index();
	cicn_copy_image_and_mask_rectangle(0, 2 * thumb_height, 0, 0, thumb_width, thumb_height);
	add_new_pxm_index();
	cicn_copy_image_and_mask_rectangle(0, 3 * thumb_height, 0, 0, thumb_width, thumb_height);
	
	cicn_store_pxm(pxm_id, "", false);
	
	return;
}

void control_clear_coordinates(void)
{
	for(int i = 0; i < 12; i++)
	{
		coordinate[i].coordinate_type = LAYO_STANDARD_COORD;
		coordinate[i].primary_ref = 0;
		coordinate[i].primary_offset = 0;
		coordinate[i].coordinate_stip = LAYO_STIP_NONE;
		coordinate[i].secondary_ref = 0;
		coordinate[i].secondary_offset = 0;		
	}
}

// Adds all of the new coordinates for a VH structure to the current layo.
void control_load_vh_coordinates(cinf_result_t cinf_result, 
								 signed int top_offset, signed int left_offset,
								 signed int bottom_offset, signed int right_offset)
{
	control_clear_coordinates();
	// Outermost edges
	coordinate[0].primary_ref = LAYO_DEFAULT_TOP;
	coordinate[0].primary_offset = top_offset;
	coordinate[1].primary_ref = LAYO_DEFAULT_LEFT;
	coordinate[1].primary_offset = left_offset;
	coordinate[2].primary_ref = LAYO_DEFAULT_BOTTOM;
	coordinate[2].primary_offset = bottom_offset;
	coordinate[3].primary_ref = LAYO_DEFAULT_RIGHT;
	coordinate[3].primary_offset = right_offset;
	// Corner Edges
	coordinate[4].primary_ref = LAYO_DEFAULT_TOP;
	coordinate[4].primary_offset = top_offset + cinf_result.corner_size;
	coordinate[5].primary_ref = LAYO_DEFAULT_LEFT;
	coordinate[5].primary_offset = left_offset + cinf_result.corner_size;
	coordinate[6].primary_ref = LAYO_DEFAULT_BOTTOM;
	coordinate[6].primary_offset = bottom_offset - cinf_result.corner_size;
	coordinate[7].primary_ref = LAYO_DEFAULT_RIGHT;
	coordinate[7].primary_offset = right_offset - cinf_result.corner_size;
	// Edge Edges
	coordinate[8].primary_ref = LAYO_DEFAULT_TOP;
	coordinate[8].primary_offset = top_offset + cinf_result.side_thickness;
	coordinate[9].primary_ref = LAYO_DEFAULT_LEFT;
	coordinate[9].primary_offset = left_offset + cinf_result.side_thickness;
	coordinate[10].primary_ref = LAYO_DEFAULT_BOTTOM;
	coordinate[10].primary_offset = bottom_offset - cinf_result.side_thickness;
	coordinate[11].primary_ref = LAYO_DEFAULT_RIGHT;
	coordinate[11].primary_offset = right_offset - cinf_result.side_thickness;
	
	return;
}

// Adds an item with default bounds and specified offsets.
void control_add_vh_structure_offset(layo_item_t layo_item, signed int resource_id,
									  signed int top_offset, signed int left_offset,
									  signed int bottom_offset, signed int right_offset)
{
	layo_item.image_ref.resource_id = resource_id;
	control_load_vh_coordinates(cinf_result, top_offset, left_offset, bottom_offset, right_offset);
	
	layo_add_vh_structure( coordinate[0], coordinate[1], coordinate[2], coordinate[3],
						   coordinate[4], coordinate[5], coordinate[6], coordinate[7],
						   coordinate[8], coordinate[9], coordinate[10], coordinate[11],
						   layo_item, cinf_result.background_plut_id,
						   cinf_result.side_thickness - cinf_result.corner_size );	
}

// Adds an item with default bounds and zero offset.
void control_add_vh_structure(layo_item_t layo_item, signed int resource_id)
{
	control_add_vh_structure_offset( layo_item, resource_id, 0, 0, 0, 0 );
}

void control_run(void)
{
	
//	// Root Menu Bar
//	cinf_vh_parse(-12240, 2560, CLR_NONE);                          // Background
//	cinf_vh_parse(-12239, 2600, CLR_ROOT_MENU_ACTIVE_TEXT_COLOR);   // Item
//	cinf_calc_disabled_color(CLR_ROOT_MENU_DISABLED_TEXT_COLOR);    // Disabled Item (text color only)
//	cinf_vh_parse(-12238, 2601, CLR_ROOT_MENU_SELECTED_TEXT_COLOR); // Selected Item
	
//	// Sliders
//	cinf_h_parse(-10144, 4220, CLR_NONE);       // Inactive South
//	cinf_h_parse(-10143, 4221, CLR_NONE);       // Active South
//	cinf_h_parse(-10142, 4222, CLR_NONE);       // Pressed South
//	control_parse_h_slider_thumb(-10141, 4223); // Thumb South
	
	// *** Push Button ***
		// Button
	layo_clear_canvas();
	cinf_result = cinf_vh_parse(-10240, 5000, "Inactive Push Button", CLR_PUSH_BUTTON_INACTIVE_TEXT_COLOR); // Inactive
	control_add_vh_structure(inactive_push_button, 5000);
	cinf_result = cinf_vh_parse(-10239, 5001, "Active Push Button", CLR_PUSH_BUTTON_ACTIVE_TEXT_COLOR);   // Active
	control_add_vh_structure(active_push_button, 5001);
	cinf_result = cinf_vh_parse(-10238, 5002, "Pressed Push Button", CLR_PUSH_BUTTON_PRESSED_TEXT_COLOR);  // Pressed
	control_add_vh_structure(pressed_push_button, 5002);
		// Text box
	control_clear_coordinates();
	coordinate[0].primary_ref = LAYO_DEFAULT_TOP;
	coordinate[1].primary_ref = LAYO_DEFAULT_LEFT;
	//coordinate[1].primary_offset = cinf_result.corner_size;
	coordinate[2].primary_ref = LAYO_DEFAULT_BOTTOM;
	coordinate[3].primary_ref = LAYO_DEFAULT_RIGHT;
	//coordinate[3].primary_offset = -(cinf_result.corner_size);
	layo_add_text_box(coordinate[0], coordinate[1], coordinate[2], coordinate[3], push_button_text, 0);
	
	layo_store_layo(500, "Push Button");
	
	// *** Default Push Button ***
	layo_clear_canvas();
		// Ring
	cinf_result = cinf_vh_parse(-10232, 5013, "Inactive Default Push Button Ring", CLR_NONE); // Inactive Ring
	cinf_result.background_plut_id = 0;  // Clear background for Ring.
	control_add_vh_structure_offset(inactive_push_button, 5013, -4, -4, 4, 4);
	cinf_result = cinf_vh_parse(-10231, 5014, "Active Default Push Button Ring", CLR_NONE); // Active Ring
	cinf_result.background_plut_id = 0;  // Clear background for Ring.
	control_add_vh_structure_offset(active_push_button, 5014, -4, -4, 4, 4);
	cinf_result = cinf_vh_parse(-10231, 5015, "Pressed Default Push Button Ring", CLR_NONE); // Pressed Ring
	cinf_result.background_plut_id = 0;  // Clear background for Ring.
	control_add_vh_structure_offset(pressed_push_button, 5015, -4, -4, 4, 4);
		// Button
	cinf_result = cinf_vh_parse(-10240, 5010, "Inactive Default Push Button", CLR_PUSH_BUTTON_INACTIVE_TEXT_COLOR); // Inactive
	control_add_vh_structure(inactive_push_button, 5010);
	cinf_result = cinf_vh_parse(-10239, 5011, "Active Default Push Button", CLR_PUSH_BUTTON_ACTIVE_TEXT_COLOR);   // Active
	control_add_vh_structure(active_push_button, 5011);
	cinf_result = cinf_vh_parse(-10238, 5012, "Pressed Default Push Button", CLR_PUSH_BUTTON_PRESSED_TEXT_COLOR);  // Pressed
	control_add_vh_structure(pressed_push_button, 5012);
		// Text
	control_clear_coordinates();
	coordinate[0].primary_ref = LAYO_DEFAULT_TOP;
	coordinate[1].primary_ref = LAYO_DEFAULT_LEFT;
	//coordinate[1].primary_offset = cinf_result.corner_size;
	coordinate[2].primary_ref = LAYO_DEFAULT_BOTTOM;
	coordinate[3].primary_ref = LAYO_DEFAULT_RIGHT;
	//coordinate[3].primary_offset = -(cinf_result.corner_size);
	layo_add_text_box(coordinate[0], coordinate[1], coordinate[2], coordinate[3], push_button_text, 0);
		// Save
	layo_store_layo(501, "Default Push Button");	
	
	// *** Small Bevel Button ***
	layo_clear_canvas();
		// off
	cinf_result = cinf_vh_parse(-10175, 5300, "Small Bevel Button Off", CLR_BEVEL_BUTTON_OFF_ENABLED_TEXT_COLOR);
	control_add_vh_structure(off_bevel_button, 5300);
		// on
	cinf_result = cinf_vh_parse(-10172, 5301, "Small Bevel Button On", CLR_BEVEL_BUTTON_ON_ENABLED_TEXT_COLOR);
	control_add_vh_structure(on_bevel_button, 5301);
		// mixed
	cinf_result = cinf_vh_parse(-10172, 5302, "Small Bevel Button Mixed", CLR_NONE);
	control_add_vh_structure(mixed_bevel_button, 5302);
		// off pressed
	cinf_result = cinf_vh_parse(-10174, 5303, "Small Bevel Button Off Pressed", CLR_BEVEL_BUTTON_PRESSED_TEXT_COLOR);
	control_add_vh_structure(off_pressed_bevel_button, 5303);
		// on pressed
	cinf_result = cinf_vh_parse(-10171, 5304, "Small Bevel Button On Pressed", CLR_NONE);
	control_add_vh_structure(on_pressed_bevel_button, 5304);
		// mixed pressed
	cinf_result = cinf_vh_parse(-10171, 5305, "Small Bevel Button Mixed Pressed", CLR_NONE);
	control_add_vh_structure(mixed_pressed_bevel_button, 5305);
		// off disabled
	cinf_result = cinf_vh_parse(-10176, 5306, "Small Bevel Button Off Disabled", CLR_BEVEL_BUTTON_OFF_DISABLED_TEXT_COLOR);
	control_add_vh_structure(off_disabled_bevel_button, 5306);
		// on disabled
	cinf_result = cinf_vh_parse(-10173, 5307, "Small Bevel Button On Disabled", CLR_BEVEL_BUTTON_ON_DISABLED_TEXT_COLOR);
	control_add_vh_structure(on_disabled_bevel_button, 5307);
		// mixed disabled
	cinf_result = cinf_vh_parse(-10173, 5308, "Small Bevel Button Mixed Disabled", CLR_NONE);
	control_add_vh_structure(mixed_disabled_bevel_button, 5308);
		// Text
	control_clear_coordinates();
	coordinate[0].primary_ref = LAYO_DEFAULT_TOP;
	coordinate[0].primary_offset = 2;
	coordinate[1].primary_ref = LAYO_DEFAULT_LEFT;
	coordinate[1].primary_offset = 2;
	coordinate[2].primary_ref = LAYO_DEFAULT_BOTTOM;
	coordinate[2].primary_offset = -2;
	coordinate[3].primary_ref = LAYO_DEFAULT_RIGHT;
	coordinate[3].primary_offset = -2;
	layo_add_text_box(coordinate[0], coordinate[1], coordinate[2], coordinate[3], bevel_button_text, 0);
		// Save
	layo_store_layo(530, "Small Bevel Button");	

	// *** Medium Bevel Button ***
	layo_clear_canvas();
		// off
	cinf_result = cinf_vh_parse(-10166, 5310, "Medium Bevel Button Off", CLR_BEVEL_BUTTON_OFF_ENABLED_TEXT_COLOR);
	control_add_vh_structure(off_bevel_button, 5310);
		// on
	cinf_result = cinf_vh_parse(-10163, 5311, "Medium Bevel Button On", CLR_BEVEL_BUTTON_ON_ENABLED_TEXT_COLOR);
	control_add_vh_structure(on_bevel_button, 5311);
		// mixed
	cinf_result = cinf_vh_parse(-10163, 5312, "Medium Bevel Button Mixed", CLR_NONE);
	control_add_vh_structure(mixed_bevel_button, 5312);
		// off pressed
	cinf_result = cinf_vh_parse(-10165, 5313, "Medium Bevel Button Off Pressed", CLR_BEVEL_BUTTON_PRESSED_TEXT_COLOR);
	control_add_vh_structure(off_pressed_bevel_button, 5313);
		// on pressed
	cinf_result = cinf_vh_parse(-10162, 5314, "Medium Bevel Button On Pressed", CLR_NONE);
	control_add_vh_structure(on_pressed_bevel_button, 5314);
		// mixed pressed
	cinf_result = cinf_vh_parse(-10162, 5315, "Medium Bevel Button Mixed Pressed", CLR_NONE);
	control_add_vh_structure(mixed_pressed_bevel_button, 5315);
		// off disabled
	cinf_result = cinf_vh_parse(-10167, 5316, "Medium Bevel Button Off Disabled", CLR_BEVEL_BUTTON_OFF_DISABLED_TEXT_COLOR);
	control_add_vh_structure(off_disabled_bevel_button, 5316);
		// on disabled
	cinf_result = cinf_vh_parse(-10164, 5317, "Medium Bevel Button On Disabled", CLR_BEVEL_BUTTON_ON_DISABLED_TEXT_COLOR);
	control_add_vh_structure(on_disabled_bevel_button, 5317);
		// mixed disabled
	cinf_result = cinf_vh_parse(-10164, 5318, "Medium Bevel Button Mixed Disabled", CLR_NONE);
	control_add_vh_structure(mixed_disabled_bevel_button, 5318);
		// Text
	control_clear_coordinates();
	coordinate[0].primary_ref = LAYO_DEFAULT_TOP;
	coordinate[0].primary_offset = 3;
	coordinate[1].primary_ref = LAYO_DEFAULT_LEFT;
	coordinate[1].primary_offset = 3;
	coordinate[2].primary_ref = LAYO_DEFAULT_BOTTOM;
	coordinate[2].primary_offset = -3;
	coordinate[3].primary_ref = LAYO_DEFAULT_RIGHT;
	coordinate[3].primary_offset = -3;
	layo_add_text_box(coordinate[0], coordinate[1], coordinate[2], coordinate[3], bevel_button_text, 0);
		// Save
	layo_store_layo(531, "Medium Bevel Button");	

	// *** Large Bevel Button ***
	layo_clear_canvas();
		// off
	cinf_result = cinf_vh_parse(-10157, 5320, "Large Bevel Button Off", CLR_BEVEL_BUTTON_OFF_ENABLED_TEXT_COLOR);
	control_add_vh_structure(off_bevel_button, 5320);
		// on
	cinf_result = cinf_vh_parse(-10154, 5321, "Large Bevel Button On", CLR_BEVEL_BUTTON_ON_ENABLED_TEXT_COLOR);
	control_add_vh_structure(on_bevel_button, 5321);
		// mixed
	cinf_result = cinf_vh_parse(-10154, 5322, "Large Bevel Button Mixed", CLR_NONE);
	control_add_vh_structure(mixed_bevel_button, 5322);
		// off pressed
	cinf_result = cinf_vh_parse(-10156, 5323, "Large Bevel Button Off Pressed", CLR_BEVEL_BUTTON_PRESSED_TEXT_COLOR);
	control_add_vh_structure(off_pressed_bevel_button, 5323);
		// on pressed
	cinf_result = cinf_vh_parse(-10153, 5324, "Large Bevel Button On Pressed", CLR_NONE);
	control_add_vh_structure(on_pressed_bevel_button, 5324);
		// mixed pressed
	cinf_result = cinf_vh_parse(-10153, 5325, "Large Bevel Button Mixed Pressed", CLR_NONE);
	control_add_vh_structure(mixed_pressed_bevel_button, 5325);
		// off disabled
	cinf_result = cinf_vh_parse(-10158, 5326, "Large Bevel Button Off Disabled", CLR_BEVEL_BUTTON_OFF_DISABLED_TEXT_COLOR);
	control_add_vh_structure(off_disabled_bevel_button, 5326);
		// on disabled
	cinf_result = cinf_vh_parse(-10155, 5327, "Large Bevel Button On Disabled", CLR_BEVEL_BUTTON_ON_DISABLED_TEXT_COLOR);
	control_add_vh_structure(on_disabled_bevel_button, 5327);
		// mixed disabled
	cinf_result = cinf_vh_parse(-10155, 5328, "Large Bevel Button Mixed Disabled", CLR_NONE);
	control_add_vh_structure(mixed_disabled_bevel_button, 5328);
		// Text
	control_clear_coordinates();
	coordinate[0].primary_ref = LAYO_DEFAULT_TOP;
	coordinate[0].primary_offset = 4;
	coordinate[1].primary_ref = LAYO_DEFAULT_LEFT;
	coordinate[1].primary_offset = 4;
	coordinate[2].primary_ref = LAYO_DEFAULT_BOTTOM;
	coordinate[2].primary_offset = -4;
	coordinate[3].primary_ref = LAYO_DEFAULT_RIGHT;
	coordinate[3].primary_offset = -4;
	layo_add_text_box(coordinate[0], coordinate[1], coordinate[2], coordinate[3], bevel_button_text, 0);
		// Save
	layo_store_layo(532, "Large Bevel Button");	
	
	// *** Tab Pane ***
	layo_clear_canvas();
		// inactive
	cinf_result = cinf_vh_parse(-9970, 3000, "Tab Pane Disabled", CLR_NONE);
	control_add_vh_structure(inactive_tab_pane, 3000);
		// active
	cinf_result = cinf_vh_parse(-9969, 3001, "Tab Pane", CLR_NONE);
	control_add_vh_structure(active_tab_pane, 3001);
		// Save
	layo_store_layo(300, "Tab Pane");	
	
	// *** North Tab ***
	layo_clear_canvas();
		// Front
	cinf_result = cinf_vh_parse(-9980, 3100, "Large North Tab Front", CLR_TAB_FRONT_ACTIVE_TEXT_COLOR);
	control_add_vh_structure_offset(front_tab, 3100, 0, 0, 1, 0);
		// Front Disabled
	cinf_result = cinf_vh_parse(-9981, 3101, "Large North Tab Front Disabled", CLR_TAB_FRONT_INACTIVE_TEXT_COLOR);
	control_add_vh_structure_offset(front_disabled_tab, 3101, 0, 0, 1, 0);
		// Rear
	cinf_result = cinf_vh_parse(-9983, 3102, "Large North Tab Rear", CLR_TAB_REAR_ACTIVE_TEXT_COLOR);
	control_add_vh_structure_offset(rear_tab, 3102, 0, 0, -3, 0);
		// Rear Disabled
	cinf_result = cinf_vh_parse(-9984, 3103, "Large North Tab Rear Disabled", CLR_TAB_REAR_INACTIVE_TEXT_COLOR);
	control_add_vh_structure_offset(rear_disabled_tab, 3103, 0, 0, -3, 0);
		// Pressed
	cinf_result = cinf_vh_parse(-9982, 3104, "Large North Tab Pressed", CLR_TAB_PRESSED_TEXT_COLOR);
	control_add_vh_structure_offset(pressed_tab, 3104, 0, 0, -3, 0);
		// Text
	coordinate[1].primary_offset = 12;
	coordinate[3].primary_offset = -12;
	layo_add_text_box(coordinate[0], coordinate[1], coordinate[2], coordinate[3], tab_text, 0);
		// Save
	layo_store_layo(310, "Large North Tab");	
	
	
	return;
}
