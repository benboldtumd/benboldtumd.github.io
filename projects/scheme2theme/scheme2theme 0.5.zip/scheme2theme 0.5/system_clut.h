#ifndef SYSTEM_CLUT_H
#define SYSTEM_CLUT_H

void make_system_clut(void);

#endif