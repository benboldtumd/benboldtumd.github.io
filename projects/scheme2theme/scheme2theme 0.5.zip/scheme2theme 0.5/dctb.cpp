#include "dctb.h"
#include "clr.h"
#include "plut.h"
#include "rsrc_read.h"

unsigned char* resource_data;
unsigned int resource_data_size;

void dctb_init(void)
{
	return;
}

void dctb_run(void)
{
	if(	get_resource_data("dctb", -14336, &resource_data, &resource_data_size) )
	{
		// Window Background Color
		rgb_color_t rgb_color;
		rgb_color.red = (unsigned int)resource_data[0x0A] << 8 | resource_data[0x0B];
		rgb_color.green = (unsigned int)resource_data[0x0C] << 8 | resource_data[0x0D];
		rgb_color.blue = (unsigned int)resource_data[0x0E] << 8 | resource_data[0x0F];
		
		modify_required_plut(PLUT_DOCUMENT_WINDOW_BACKGROUND, 0, rgb_color);
		modify_required_plut(PLUT_DIALOG_BACKGROUND_ACTIVE, 0, rgb_color);
		modify_required_plut(PLUT_ALERT_BACKGROUND_ACTIVE, 0, rgb_color);
		modify_required_plut(PLUT_MODELESS_DIALOG_BACKGROUND_ACTIVE, 0, rgb_color);
		modify_required_plut(PLUT_UTILITY_WINDOW_BACKGROUND_ACTIVE, 0, rgb_color);
		modify_required_plut(PLUT_OS_9_NOTIFICATION_ALERT_BACKGROUND, 0, rgb_color);
		modify_required_plut(PLUT_STATIC_AREA_FILL, 0, rgb_color);
		
		modify_required_plut(PLUT_FINDER_WINDOW_BACKGROUND, 0, rgb_color);
		modify_required_plut(PLUT_DIALOG_BACKGROUND_INACTIVE, 0, rgb_color);
		modify_required_plut(PLUT_ALERT_BACKGROUND_INACTIVE, 0, rgb_color);
		modify_required_plut(PLUT_MODELESS_DIALOG_BACKGROUND_INACTIVE, 0, rgb_color);
		modify_required_plut(PLUT_UTILITY_WINDOW_BACKGROUND_INACTIVE, 0, rgb_color);
		modify_required_plut(PLUT_OS_9_NOTIFICATION_ALERT_BACKGROUND_INACTIVE, 0, rgb_color);	
		modify_required_plut(PLUT_ACTIVE_AREA_FILL, 0, rgb_color);
		
		// Window Text Color
		rgb_color.red = (unsigned int)resource_data[0x1A] << 8 | resource_data[0x1B];
		rgb_color.green = (unsigned int)resource_data[0x1C] << 8 | resource_data[0x1D];
		rgb_color.blue = (unsigned int)resource_data[0x1E] << 8 | resource_data[0x1F];	
		
		modify_clr_entry(CLR_DIALOG_AND_POPUP_ACTIVE_TEXT_COLOR, rgb_color);
		modify_clr_entry(CLR_ALERT_ACTIVE_TEXT_COLOR, rgb_color);
		modify_clr_entry(CLR_MODELESS_DIALOG_ACTIVE_TEXT_COLOR, rgb_color);
		modify_clr_entry(CLR_NOTIFICATION_ALERT_ACTIVE_TEXT_COLOR, rgb_color);
		modify_clr_entry(CLR_TAB_FRONT_ACTIVE_TEXT_COLOR, rgb_color);
		modify_clr_entry(CLR_TAB_FRONT_INACTIVE_TEXT_COLOR, rgb_color);
	}
	return;
}