#include "cinf.h"

#include "cicn.h"
#include "rsrc_read.h"
#include "rsrc_write.h"
#include "ppat.h"

#include <iostream>
using namespace std;

unsigned char* resource_data;
unsigned int resource_data_size;

static struct
{
	cinf_data_t cinf_data;
	unsigned int dimension;
	rgb_color_t rgb_color;
	rgb_color_t rgb_color_2;
} cinf;

void cinf_init(void)
{
	return;
}

cinf_data_t cinf_get_data(signed int cinf_id)
{
	cinf_data_t cinf_data;
	
	if(get_resource_data("cinf", cinf_id, &resource_data, &resource_data_size))
	{
		cinf_data.corner_size = resource_data[0];
		cinf_data.side_thickness = resource_data[1];
		cinf_data.tile_sides = resource_data[2];
		cinf_data.pattern_anchor = resource_data[3];
		
		cinf_data.background_pattern_id = (resource_data[4] << 8) | resource_data[5];
		cinf_data.background_pixel_y = (resource_data[6] << 8) | resource_data[7];
		cinf_data.background_pixel_x = (resource_data[8] << 8) | resource_data[9];
		cinf_data.text_pixel_y = (resource_data[10] << 8) | resource_data[11];
		cinf_data.text_pixel_x = (resource_data[12] << 8) | resource_data[13];
		cinf_data.embossing_pixel_y = (resource_data[14] << 8) | resource_data[15];
		cinf_data.embossing_pixel_x = (resource_data[16] << 8) | resource_data[17];
		
		if(resource_data_size >= 0x12)  // Transparency is optional at the end of this resource.
		{
			cinf_data.transparency = (resource_data[18] << 8) | resource_data[19];
		}
		else
		{
			cinf_data.transparency = 0;  // I want this to be opaque but didn't check for sure that 0 = opaque.
		}
	}
	else
	{
		// Handle missing 'cinf' based on ID.
		switch(cinf_id)
		{
			case -10240:
			case -10239:
			case -10238:
			case -10232:
			case -10231:
			case -10176:
			case -10175:
			case -10174:
			case -10173:
			case -10172:
			case -10171:
			case -10167:
			case -10166:
			case -10165:
			case -10164:
			case -10163:
			case -10162:
			case -10158:
			case -10157:
			case -10156:
			case -10155:
			case -10154:
			case -10153:
				cinf_data.corner_size = 6;
				cinf_data.side_thickness = 6;
				cinf_data.background_pixel_y = 6;
				cinf_data.background_pixel_x = 6;
				cinf_data.text_pixel_y = 8;
				cinf_data.text_pixel_x = 8;
				cinf_data.embossing_pixel_y = 7;
				cinf_data.embossing_pixel_x = 9;
				break;
			default:
				cerr << "cinf " << cinf_id << " was missing and no default was found!\n";
				cinf_data.corner_size = 0;
				cinf_data.side_thickness = 0;
				cinf_data.background_pixel_y = 0;
				cinf_data.background_pixel_x = 0;
				cinf_data.text_pixel_y = 0;
				cinf_data.text_pixel_x = 0;
				cinf_data.embossing_pixel_y = 0;
				cinf_data.embossing_pixel_x = 0;
				break;
		}
		// These items are common to all default 'cinf's.
		cinf_data.tile_sides = 0;
		cinf_data.pattern_anchor = 0;
		cinf_data.background_pattern_id = 0;
		cinf_data.transparency = 0;
	}
	return cinf_data;	
}

cinf_result_t cinf_v_parse(signed int cinf_id, signed int pxm_id, string name, clr_color_t clr_color)
{
	cinf_result_t cinf_result;
	if(!resource_exists("cinf", cinf_id))
	{
		cerr << "Could not find 'cinf' ID#" << cinf_id << "in scheme.\n";
		cinf_result.corner_size = 0;
		cinf_result.side_thickness = 0;
		cinf_result.background_plut_id = 0;
		return cinf_result;
	}
	cinf_result.corner_size = 0;
	cinf_result.side_thickness = 0;
	cinf_result.background_plut_id = 0;
	return cinf_result;
}

cinf_result_t cinf_h_parse(signed int cinf_id, signed int pxm_id, unsigned int height, string name, clr_color_t clr_color)
{
	cinf_result_t cinf_result;
	if(!resource_exists("cinf", cinf_id))
	{
		cerr << "Could not find 'cinf' ID#" << cinf_id << "in scheme.\n";
		cinf_result.corner_size = 0;
		cinf_result.side_thickness = 0;
		cinf_result.background_plut_id = 0;
		return cinf_result;
	}
	// Get cinf data into structure.
	cinf.cinf_data = cinf_get_data(cinf_id);
	
	// Load associated cicn data.
	cicn_load_cicn(cinf_id, 2 * cinf.cinf_data.corner_size, height);
	
	unsigned int adjusted_side_thickness;
	
	adjusted_side_thickness = height;  // Be sure not to copy beyond the bounds of the original image.
	if(adjusted_side_thickness > cicn_get_source_height())
	{
		adjusted_side_thickness = cicn_get_source_height();
	}
	
	// Copy Corners
	cicn_copy_image_and_mask_rectangle(0, 0,  // Left
									   0, 0,
									   cinf.cinf_data.corner_size, adjusted_side_thickness);
	
	cicn_copy_image_and_mask_rectangle(cicn_get_source_width() - cinf.cinf_data.corner_size, 0,  // Right
									   cinf.cinf_data.corner_size, 0,
									   cinf.cinf_data.corner_size, adjusted_side_thickness);
	
	// Copy horizontal stretch
	add_new_pxm_index();
	
	// Copy only the edge, but being sure that it is still within bounds of the cicn.
	if(adjusted_side_thickness > cinf.cinf_data.side_thickness)
	{
		adjusted_side_thickness = cinf.cinf_data.side_thickness;
	}
	
	for(int i = 0; i < 2 * cinf.cinf_data.corner_size; i++)
	{
		cicn_copy_image_and_mask_rectangle(cinf.cinf_data.corner_size, cicn_get_source_height() - cinf.cinf_data.side_thickness,  // bottom
										   i, cicn_get_source_height() - cinf.cinf_data.side_thickness,
										   1, adjusted_side_thickness);
		
		// Does Top last to give precedence to top.
		cicn_copy_image_and_mask_rectangle(cinf.cinf_data.corner_size, 0,  // Top
										   i, 0,
										   1, adjusted_side_thickness);
	}
	
	modify_clr_entry(clr_color, cicn_get_pixel_color(cinf.cinf_data.text_pixel_x, cinf.cinf_data.text_pixel_y));
	
	cicn_store_pxm(pxm_id, name, false);
	
	// Copy background color / ppat.  Store this in plut, not pxm#.
	cinf.rgb_color = cicn_get_pixel_color(cinf.cinf_data.background_pixel_x, cinf.cinf_data.background_pixel_y);
	
	cinf_result.corner_size = cinf.cinf_data.corner_size;
	cinf_result.side_thickness = cinf.cinf_data.side_thickness;
	cinf_result.background_plut_id = ppat_copy(cinf.cinf_data.background_pattern_id, cinf.rgb_color);
	return cinf_result;
}

cinf_result_t cinf_vh_parse(signed int cinf_id, signed int pxm_id, string name, clr_color_t clr_color)
{
	cinf_result_t cinf_result;
	
	// Get cinf data into structure.
	cinf.cinf_data = cinf_get_data(cinf_id);
	
	// Accomodate corners or side thickness, whichever is larger.
	cinf.dimension = 2 * cinf.cinf_data.corner_size;
	if( cinf.dimension < 2 * cinf.cinf_data.side_thickness )
	{
		cinf.dimension = 2 * cinf.cinf_data.side_thickness;
	}
	
	// Load associated cicn data.
	cicn_load_cicn(cinf_id, cinf.dimension, cinf.dimension);
	
	// Copy Corners
	cicn_copy_image_and_mask_rectangle(0, 0,  // Top Left
									   0, 0,
									   cinf.cinf_data.corner_size, cinf.cinf_data.corner_size);
	
	cicn_copy_image_and_mask_rectangle(cicn_get_source_width() - cinf.cinf_data.corner_size, 0,  // Top Right
									   cinf.dimension - cinf.cinf_data.corner_size, 0,
									   cinf.cinf_data.corner_size, cinf.cinf_data.corner_size);
	
	cicn_copy_image_and_mask_rectangle(0, cicn_get_source_height() - cinf.cinf_data.corner_size,  // Bottom Left
									   0, cinf.dimension - cinf.cinf_data.corner_size,
									   cinf.cinf_data.corner_size, cinf.cinf_data.corner_size);
	
	cicn_copy_image_and_mask_rectangle(cicn_get_source_width() - cinf.cinf_data.corner_size, cicn_get_source_height() - cinf.cinf_data.corner_size,  // Bottom Right
									   cinf.dimension - cinf.cinf_data.corner_size, cinf.dimension - cinf.cinf_data.corner_size,
									   cinf.cinf_data.corner_size, cinf.cinf_data.corner_size);
	
	// Copy top and bottom
	add_new_pxm_index();
	
	unsigned int adjusted_side_thickness;
	adjusted_side_thickness = cinf.cinf_data.side_thickness;  // Prevents copying image data that doesn't exist.
	if(adjusted_side_thickness > cicn_get_source_height())
	{
		adjusted_side_thickness = cicn_get_source_height();
	}
	
	for(int i = 0; i < cinf.dimension; i++)
	{
		cicn_copy_image_and_mask_rectangle(cinf.cinf_data.corner_size, 0,  // Top Edge
										   i, 0,
										   1, adjusted_side_thickness);
		
		cicn_copy_image_and_mask_rectangle(cinf.cinf_data.corner_size, cicn_get_source_height() - adjusted_side_thickness,  // Bottom Edge
										   i, cinf.dimension - adjusted_side_thickness,
										   1, adjusted_side_thickness);
	}
	
	// Copy left and right
	add_new_pxm_index();
	
	adjusted_side_thickness = cinf.cinf_data.side_thickness;  // Prevents copying image data that doesn't exist.
	if(adjusted_side_thickness > cicn_get_source_width())
	{
		adjusted_side_thickness = cicn_get_source_width();
	}
	
	for(int i = 0; i < cinf.dimension; i++)
	{
		cicn_copy_image_and_mask_rectangle(0, cinf.cinf_data.corner_size,  // Left Edge
										   0, i,
										   adjusted_side_thickness, 1);
		
		cicn_copy_image_and_mask_rectangle(cicn_get_source_width() - adjusted_side_thickness, cinf.cinf_data.corner_size,  // Right Edge
										   cinf.dimension - adjusted_side_thickness, i,
										   adjusted_side_thickness, 1);
	}
	
	cinf.rgb_color_2 = cicn_get_pixel_color(cinf.cinf_data.text_pixel_x, cinf.cinf_data.text_pixel_y);
	modify_clr_entry(clr_color, cinf.rgb_color_2);
	
	cicn_store_pxm(pxm_id, name, false);
	
	// Copy background color / ppat.  Store this in plut, not pxm#.
	cinf.rgb_color = cicn_get_pixel_color(cinf.cinf_data.background_pixel_x, cinf.cinf_data.background_pixel_y);
	
	cinf_result.corner_size = cinf.cinf_data.corner_size;
	cinf_result.side_thickness = cinf.cinf_data.side_thickness;
	cinf_result.background_plut_id = ppat_copy(cinf.cinf_data.background_pattern_id, cinf.rgb_color);
	return cinf_result;
}

unsigned int cinf_average_color(unsigned int color_1, unsigned int color_2)
{
	unsigned int color;
	color = (color_1 + color_2);
	if(color & 1)  // Rounding
	{
		color += 2;
	}
	return (color >> 1);
}

void cinf_calc_disabled_color(clr_color_t clr_color)
{
	cinf.rgb_color_2.red = cinf_average_color(cinf.rgb_color.red, cinf.rgb_color_2.red);
	cinf.rgb_color_2.green = cinf_average_color(cinf.rgb_color.green, cinf.rgb_color_2.green);
	cinf.rgb_color_2.blue = cinf_average_color(cinf.rgb_color.blue, cinf.rgb_color_2.blue);
	
	modify_clr_entry(clr_color, cinf.rgb_color_2);
}
