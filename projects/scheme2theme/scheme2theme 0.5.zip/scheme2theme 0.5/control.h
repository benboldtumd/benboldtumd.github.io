#ifndef CONTROL_H
#define CONTROL_H

void control_init(void);
void control_run(void);

#endif