#ifndef ICS_H
#define ICS_H

void ics_init(void);
void ics_run(void);

#endif