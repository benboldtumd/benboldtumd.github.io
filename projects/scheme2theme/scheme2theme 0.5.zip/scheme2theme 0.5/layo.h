#ifndef LAYO_H
#define LAYO_H

#include <string>
using namespace std;

// Memory Allocation
#define LAYO_MAX_COORDINATES 256
#define LAYO_MAX_ITEMS 256

// Default reference locations
#define LAYO_DEFAULT_TOP    -1
#define LAYO_DEFAULT_LEFT   -2
#define LAYO_DEFAULT_BOTTOM -3
#define LAYO_DEFAULT_RIGHT  -4

// Visible Only If and Invisible If bitfield bits.  (OR them together.)
#define LAYO_FLAG_INACTIVE                       (1 << 0)
//#define LAYO_FLAG_HAS_RIGHT_GROWBOX              (1 << 0)

#define LAYO_FLAG_ON                             (1 << 1)
#define LAYO_FLAG_DISABLED                        (1 << 1)
//#define LAYO_FLAG_MENU_CAN_SCROLL                (1 << 1)
//#define LAYO_FLAG_HAS_LEFT_GROWBOX               (1 << 1)

#define LAYO_FLAG_MIXED                          (1 << 2)
#define LAYO_FLAG_SUBMENU                        (1 << 2)
//#define LAYO_FLAG_HAS_TEXT                       (1 << 2)
//#define LAYO_FLAG_HAS_SUBMENU                    (1 << 2)
//#define LAYO_FLAG_IS_FOCUS                       (1 << 2)

#define LAYO_FLAG_H_ZOOM                         (1 << 3)
#define LAYO_FLAG_SCROLLS_DOWN                   (1 << 3)
//#define LAYO_FLAG_IS_ACTIVE                      (1 << 3)

#define LAYO_FLAG_V_ZOOM                         (1 << 4)
#define LAYO_FLAG_SCROLLS_UP                     (1 << 4)

#define LAYO_FLAG_PRESSED                        (1 << 5)
//#define LAYO_FLAG_HAS_CLOSE                      (1 << 5)

#define LAYO_FLAG_INDETERMINATE_PROGRESS_FRAME_1 (1 << 6)
//#define LAYO_FLAG_HAS_COLLAPSE                   (1 << 6)

#define LAYO_FLAG_ALTERNATE_CHECKBOX             (1 << 7)
#define LAYO_FLAG_INDETERMINATE_PROGRESS_FRAME_2 (1 << 7)
//#define LAYO_FLAG_HAS_TITLE_TEXT                 (1 << 7)

#define LAYO_FLAG_SUBMENU_ON_LEFT                (1 << 8)
#define LAYO_FLAG_INDETERMINATE_PROGRESS_FRAME_3 (1 << 8)
//#define LAYO_FLAG_IS_COLLAPSED                   (1 << 8)

#define LAYO_FLAG_INDETERMINATE_PROGRESS_FRAME_4 (1 << 9)

#define LAYO_FLAG_INDETERMINATE_PROGRESS_ACTIVE  (1 << 10)

// Attribute bitfield bits
#define LAYO_ATTR_TITLE_BAR        (1 << 0)
#define LAYO_ATTR_CLICK_ACTION     (1 << 1)  // Not for sure on this bit.
#define LAYO_ATTR_CLOSE_WIDGET     (1 << 2)
#define LAYO_ATTR_ZOOM_WIDGET      (1 << 3)
#define LAYO_ATTR_MYSTERY          (1 << 4)
#define LAYO_ATTR_DRAGGABLE        (1 << 5)
#define LAYO_ATTR_GROW_BOX         (1 << 6)
#define LAYO_ATTR_COLLAPSE_WIDGET  (1 << 7)
#define LAYO_ATTR_VISIBLE          (1 << 8)
#define LAYO_ATTR_CONTENT_AREA     (1 << 9)
#define LAYO_ATTR_DRAWER_GROW_BOX  (1 << 10)
#define LAYO_ATTR_MODAL_GROW_BOX   (1 << 11)
#define LAYO_ATTR_RIGHT_GROW_BOX   (1 << 12)
#define LAYO_ATTR_LEFT_GROW_BOX    (1 << 13)
#define LAYO_ATTR_TAB_PANE_CONTENT (1 << 29)

enum coordinate_type_t
{
	LAYO_STANDARD_COORD  = 0,
	LAYO_VARIABLE_COORD  = 1,
	LAYO_CENTERING_COORD = 2
};

enum coordinate_stip_t // Stipulation types
{
	LAYO_STIP_NONE      = 0,
	LAYO_STIP_CONSTRAIN = 1,
	LAYO_STIP_COLLAPSE  = 2,
	LAYO_STIP_SNAP_IN   = 3,
	LAYO_STIP_SNAP_OUT  = 4
};

typedef struct
{
	coordinate_type_t coordinate_type;
	signed int primary_ref; // Use LAYO_DEFAULT_xxxx defines or references to other coordinates.
	signed int primary_offset;
	coordinate_stip_t coordinate_stip;
	signed int secondary_ref; // Use LAYO_DEFAULT_xxxx defines or references to other coordinates.
	signed int secondary_offset;
} layo_coordinate_t;

enum layo_image_alignment_t
{
	LAYO_TOP_LEFT      = 1,
	LAYO_TOP_RIGHT     = 2,
	LAYO_BOTTOM_LEFT   = 3,
	LAYO_BOTTOM_RIGHT  = 4,
	LAYO_SCREEN_ORIGIN = 0
};

typedef struct
{
	string resource_type;
	signed int top;
	signed int left;
	signed int bottom;
	signed int right;
	signed int resource_id;
	unsigned int image_index;
	layo_image_alignment_t image_alignment;
} layo_image_ref_t;

typedef struct
{
	unsigned int visible_only_if_bitfield;
	unsigned int invisible_if_bitfield;
	unsigned int attribute_bitfield;
	layo_image_ref_t image_ref;
} layo_item_t;

void layo_init( void );

void layo_clear_canvas( void );

// Add coordinates manually for centering and variable types.
unsigned int layo_add_coordinate ( layo_coordinate_t coordinate );

// Add items manually when they are not typical 'cinf' types.
void layo_add_item_relative	( signed int top, signed int left,
							  signed int bottom, signed int right,
							  layo_item_t item );

void layo_add_item			( layo_coordinate_t top, layo_coordinate_t left,
							  layo_coordinate_t bottom, layo_coordinate_t right,
							  layo_item_t item );

// Automatic functions for all the little pieces of a typical 'cinf' type.
void layo_add_vh_structure	( layo_coordinate_t top, layo_coordinate_t left,
							  layo_coordinate_t bottom, layo_coordinate_t right,
							  layo_coordinate_t corner_top, layo_coordinate_t corner_left,
							  layo_coordinate_t corner_bottom, layo_coordinate_t corner_right,
							  layo_coordinate_t edge_top, layo_coordinate_t edge_left,
							  layo_coordinate_t edge_bottom, layo_coordinate_t edge_right,
							  layo_item_t item, signed int plut_background,
							  signed int edge_corner_diff);

void layo_add_h_structure	( layo_coordinate_t top, layo_coordinate_t left,
							  layo_coordinate_t bottom, layo_coordinate_t right,
							  layo_coordinate_t corner_left, layo_coordinate_t corner_right,
							  layo_coordinate_t edge_top, layo_coordinate_t edge_bottom,
							  layo_item_t item, signed int plut_background,
							  signed int edge_corner_diff);

void layo_add_v_structure	( layo_coordinate_t top, layo_coordinate_t left,
							  layo_coordinate_t bottom, layo_coordinate_t right,
							  layo_coordinate_t corner_top, layo_coordinate_t corner_bottom,
							  layo_coordinate_t edge_top, layo_coordinate_t edge_bottom,
							  layo_item_t item, signed int plut_background,
							  signed int edge_corner_diff);
						   
void layo_add_text_box		( layo_coordinate_t top, layo_coordinate_t left,
							  layo_coordinate_t bottom, layo_coordinate_t right,
							  layo_item_t item, signed int plut_background );

// Adds a content area item with default top, left, bottom, and right bounds.
void layo_add_default_content_area( void );

// Stores the layo into the theme resource fork.
void layo_store_layo( unsigned int layo_id, string name );

#endif
