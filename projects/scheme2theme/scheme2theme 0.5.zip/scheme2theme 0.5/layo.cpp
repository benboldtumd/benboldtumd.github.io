#include "layo.h"
#include "rsrc_write.h"

#include <iostream>
using namespace std;

typedef struct
{
	unsigned int coordinate_count;
	layo_coordinate_t coordinate[LAYO_MAX_COORDINATES];
	unsigned int item_count;
	layo_item_t item[LAYO_MAX_ITEMS];
} layo_resource_t;

layo_resource_t layo;

unsigned char layo_data[10240];
unsigned int layo_data_size;

void layo_init( void )
{
	layo.coordinate_count = 0;
	layo.item_count = 0;
	layo_data_size = 0;
	return;
}

void layo_clear_canvas( void )
{
	layo.coordinate_count = 0;
	layo.item_count = 0;
	layo_data_size = 0;
	return;
}

unsigned int layo_add_coordinate( layo_coordinate_t coordinate )
{
	// First see if this even needs a coordinate entry.
	if(	coordinate.coordinate_type == LAYO_STANDARD_COORD &&
		coordinate.primary_offset == 0 &&
		coordinate.coordinate_stip == LAYO_STIP_NONE &&
		coordinate.secondary_ref == 0 &&
		coordinate.secondary_offset == 0
		)
	{
		return coordinate.primary_ref;  // This type of reference can be entered into the item entry directly.  No coordinate necessary.
	}
	
	// Next search to see if this coordinate already exists and reuse if found.
	for(int i = 0; i < layo.coordinate_count; i++)
	{
		if(	layo.coordinate[i].coordinate_type == coordinate.coordinate_type &&
			layo.coordinate[i].primary_ref == coordinate.primary_ref &&
			layo.coordinate[i].primary_offset == coordinate.primary_offset &&
			layo.coordinate[i].coordinate_stip == coordinate.coordinate_stip &&
			layo.coordinate[i].secondary_ref == coordinate.secondary_ref &&
			layo.coordinate[i].secondary_offset == coordinate.secondary_offset
		)
		{
			return (i + 1);  // Found a matching coordinate.  Return this reference number.
		}
	}
	
	// If this function did not exit in the search, add new coordinate.
	// Copy new data into coordinate structure.
	layo.coordinate[layo.coordinate_count].coordinate_type = coordinate.coordinate_type;
	layo.coordinate[layo.coordinate_count].primary_ref = coordinate.primary_ref;
	layo.coordinate[layo.coordinate_count].primary_offset = coordinate.primary_offset;
	layo.coordinate[layo.coordinate_count].coordinate_stip = coordinate.coordinate_stip;
	layo.coordinate[layo.coordinate_count].secondary_ref = coordinate.secondary_ref;
	layo.coordinate[layo.coordinate_count].secondary_offset = coordinate.secondary_offset;

	// Increment coordinate counter.
	layo.coordinate_count++;

	// Return the count (reference number) for this new coordinate.
	return layo.coordinate_count;
}

void layo_add_item_relative( signed int top, signed int left,
							 signed int bottom, signed int right,
							 layo_item_t item )
{
	
	// Copy new data into item structure.
	layo.item[layo.item_count].visible_only_if_bitfield = item.visible_only_if_bitfield;
	layo.item[layo.item_count].invisible_if_bitfield    = item.invisible_if_bitfield;
	layo.item[layo.item_count].attribute_bitfield       = item.attribute_bitfield;
	
	// Add coordinates needed for this item, and store references to the new coordinates.
	layo.item[layo.item_count].image_ref.top    = top;
	layo.item[layo.item_count].image_ref.left   = left;
	layo.item[layo.item_count].image_ref.bottom = bottom;
	layo.item[layo.item_count].image_ref.right  = right;
	
	layo.item[layo.item_count].image_ref.resource_type   = item.image_ref.resource_type;
	layo.item[layo.item_count].image_ref.resource_id     = item.image_ref.resource_id;
	layo.item[layo.item_count].image_ref.image_index     = item.image_ref.image_index;
	layo.item[layo.item_count].image_ref.image_alignment = item.image_ref.image_alignment;
	
	// Increment item counter.
	layo.item_count++;

	return;
}

void layo_add_item( layo_coordinate_t top, layo_coordinate_t left,
					layo_coordinate_t bottom, layo_coordinate_t right,
					layo_item_t item )
{
	layo_add_item_relative(layo_add_coordinate(top),
						   layo_add_coordinate(left),
						   layo_add_coordinate(bottom),
						   layo_add_coordinate(right),
						   item);
	return;
}

void layo_add_vh_structure( layo_coordinate_t top, layo_coordinate_t left,
							layo_coordinate_t bottom, layo_coordinate_t right,
							layo_coordinate_t corner_top, layo_coordinate_t corner_left,
							layo_coordinate_t corner_bottom, layo_coordinate_t corner_right,
							layo_coordinate_t edge_top, layo_coordinate_t edge_left,
							layo_coordinate_t edge_bottom, layo_coordinate_t edge_right,
							layo_item_t item, signed int plut_background,
							signed int edge_corner_diff)
{
	signed int coord_ref[12];
	coord_ref[0] = layo_add_coordinate(top);
	coord_ref[1] = layo_add_coordinate(left);
	coord_ref[2] = layo_add_coordinate(bottom);
	coord_ref[3] = layo_add_coordinate(right);
	
	coord_ref[4] = layo_add_coordinate(corner_top);
	coord_ref[5] = layo_add_coordinate(corner_left);
	coord_ref[6] = layo_add_coordinate(corner_bottom);
	coord_ref[7] = layo_add_coordinate(corner_right);
	
	coord_ref[8] = layo_add_coordinate(edge_top);
	coord_ref[9] = layo_add_coordinate(edge_left);
	coord_ref[10] = layo_add_coordinate(edge_bottom);
	coord_ref[11] = layo_add_coordinate(edge_right);
	
	// Plut Background stretch (if specified)
	if(plut_background != 0)
	{
		// Create new item for this purpose.
		layo_item_t plut_item;
		plut_item.visible_only_if_bitfield = item.visible_only_if_bitfield;
		plut_item.invisible_if_bitfield    = item.invisible_if_bitfield;
		plut_item.attribute_bitfield       = item.attribute_bitfield;

		plut_item.image_ref.resource_type   = "plut";
		plut_item.image_ref.resource_id     = plut_background;
		plut_item.image_ref.image_index     = 0;
		plut_item.image_ref.image_alignment	= LAYO_TOP_LEFT;
		
		// The background must fill exactly the area not taken up by the corners and edges
		// in case the corners/edges are not completely opaque.
		
		// If edge thickness is greater than or equal to corner size, the background fills in a rectangle shape.
		if(edge_corner_diff >= 0)
		{
			layo_add_item_relative(coord_ref[8], coord_ref[9], coord_ref[10], coord_ref[11], plut_item);
		}
		// If edge thickness is less than corner size, the background has to fill in a + shape.
		else
		{
			layo_add_item_relative(coord_ref[8], coord_ref[5], coord_ref[10], coord_ref[7], plut_item);
			layo_add_item_relative(coord_ref[4], coord_ref[9], coord_ref[6], coord_ref[11], plut_item);
		}
	}
	
	// Corners
	item.image_ref.image_index = 0; // Corners are from index 0.
	item.image_ref.image_alignment = LAYO_TOP_LEFT;
	layo_add_item_relative(coord_ref[0], coord_ref[1], coord_ref[4], coord_ref[5], item);
	
	item.image_ref.image_alignment = LAYO_TOP_RIGHT;
	layo_add_item_relative(coord_ref[0], coord_ref[7], coord_ref[4], coord_ref[3], item);

	item.image_ref.image_alignment = LAYO_BOTTOM_LEFT;
	layo_add_item_relative(coord_ref[6], coord_ref[1], coord_ref[2], coord_ref[5], item);

	item.image_ref.image_alignment = LAYO_BOTTOM_RIGHT;
	layo_add_item_relative(coord_ref[6], coord_ref[7], coord_ref[2], coord_ref[3], item);
	
	// Top/Bottom stretch
	item.image_ref.image_index = 1; // Top/bottom are from index 1.
	item.image_ref.image_alignment = LAYO_TOP_LEFT;
	layo_add_item_relative(coord_ref[0], coord_ref[5], coord_ref[8], coord_ref[7], item);
	
	item.image_ref.image_alignment = LAYO_BOTTOM_LEFT;
	layo_add_item_relative(coord_ref[10], coord_ref[5], coord_ref[2], coord_ref[7], item);
	
	// Left/Right stretch
	item.image_ref.image_index = 2; // Left/right are from index 2.
	item.image_ref.image_alignment = LAYO_TOP_LEFT;
	layo_add_item_relative(coord_ref[4], coord_ref[1], coord_ref[6], coord_ref[9], item);
	
	item.image_ref.image_alignment = LAYO_TOP_RIGHT;
	layo_add_item_relative(coord_ref[4], coord_ref[11], coord_ref[6], coord_ref[3], item);

	return;
}

void layo_add_text_box( layo_coordinate_t top, layo_coordinate_t left,
						layo_coordinate_t bottom, layo_coordinate_t right,
						layo_item_t item, signed int plut_background )
{
	
//	item.visible_only_if_bitfield = 0;
//	item.invisible_if_bitfield = 0;
//	item.attribute_bitfield = LAYO_ATTR_TITLE_BAR | LAYO_ATTR_VISIBLE;
	if( 0 == plut_background )
	{
		item.image_ref.resource_type = "NULL";
		item.image_ref.resource_id = 0;
		item.image_ref.image_index = 0;
		item.image_ref.image_alignment = LAYO_TOP_LEFT;
	}
	else
	{
		item.image_ref.resource_type = "plut";
		item.image_ref.resource_id = plut_background;
		item.image_ref.image_index = 0;
		item.image_ref.image_alignment = LAYO_TOP_LEFT;
	}
				
	layo_add_item(top, left, bottom, right, item);
}

void layo_store_layo( unsigned int layo_id, string name )
{
	// Build header
	for(int i = 0; i < 6; i++)
	{
		layo_data[layo_data_size] = 0x00;
		layo_data_size++;
	}
	
	// Coordinate entry count
	layo_data[layo_data_size] = (layo.coordinate_count >> 8) & 0xFF;  // MSB
	layo_data[layo_data_size + 1] = layo.coordinate_count & 0xFF;  // LSB
	layo_data_size += 2;

	// Coordinate entries
	for(int i = 0; i < layo.coordinate_count; i++)
	{
		layo_data[layo_data_size] = (layo.coordinate[i].coordinate_type >> 8) & 0xFF;
		layo_data[layo_data_size + 1] = layo.coordinate[i].coordinate_type & 0xFF;
		layo_data_size += 2;
		
		layo_data[layo_data_size] = (layo.coordinate[i].primary_offset >> 8) & 0xFF;
		layo_data[layo_data_size + 1] = layo.coordinate[i].primary_offset & 0xFF;
		layo_data_size += 2;
		
		layo_data[layo_data_size] = (layo.coordinate[i].primary_ref >> 8) & 0xFF;
		layo_data[layo_data_size + 1] = layo.coordinate[i].primary_ref & 0xFF;
		layo_data_size += 2;
		
		layo_data[layo_data_size] = (layo.coordinate[i].coordinate_stip >> 8) & 0xFF;
		layo_data[layo_data_size + 1] = layo.coordinate[i].coordinate_stip & 0xFF;
		layo_data_size += 2;
		
		layo_data[layo_data_size] = (layo.coordinate[i].secondary_offset >> 8) & 0xFF;
		layo_data[layo_data_size + 1] = layo.coordinate[i].secondary_offset & 0xFF;
		layo_data_size += 2;
		
		layo_data[layo_data_size] = (layo.coordinate[i].secondary_ref >> 8) & 0xFF;
		layo_data[layo_data_size + 1] = layo.coordinate[i].secondary_ref & 0xFF;
		layo_data_size += 2;
		
		for(int j = 0; j < 4; j++) // Padding
		{
			layo_data[layo_data_size] = 0x00;
			layo_data_size++;
		}		
	}
	
	// Item entry count
	layo_data[layo_data_size] = (layo.item_count >> 8) & 0xFF;  // MSB
	layo_data[layo_data_size + 1] = layo.item_count & 0xFF;  // LSB
	layo_data_size += 2;
	
	// Item Entries
	for(int i = 0; i < layo.item_count; i++)
	{
		layo_data[layo_data_size] = (layo.item[i].visible_only_if_bitfield >> 24) & 0xFF;
		layo_data[layo_data_size+1] = (layo.item[i].visible_only_if_bitfield >> 16) & 0xFF;
		layo_data[layo_data_size+2] = (layo.item[i].visible_only_if_bitfield >> 8) & 0xFF;
		layo_data[layo_data_size+3] = layo.item[i].visible_only_if_bitfield & 0xFF;
		layo_data_size += 4;
		
		layo_data[layo_data_size] = (layo.item[i].invisible_if_bitfield >> 24) & 0xFF;
		layo_data[layo_data_size+1] = (layo.item[i].invisible_if_bitfield >> 16) & 0xFF;
		layo_data[layo_data_size+2] = (layo.item[i].invisible_if_bitfield >> 8) & 0xFF;
		layo_data[layo_data_size+3] = layo.item[i].invisible_if_bitfield & 0xFF;
		layo_data_size += 4;
		
		layo_data[layo_data_size] = (layo.item[i].attribute_bitfield >> 24) & 0xFF;
		layo_data[layo_data_size+1] = (layo.item[i].attribute_bitfield >> 16) & 0xFF;
		layo_data[layo_data_size+2] = (layo.item[i].attribute_bitfield >> 8) & 0xFF;
		layo_data[layo_data_size+3] = layo.item[i].attribute_bitfield & 0xFF;
		layo_data_size += 4;
		
		layo_data[layo_data_size] = (layo.item[i].image_ref.top >> 8) & 0xFF;
		layo_data[layo_data_size+1] = layo.item[i].image_ref.top & 0xFF;
		layo_data_size += 2;

		layo_data[layo_data_size] = (layo.item[i].image_ref.left >> 8) & 0xFF;
		layo_data[layo_data_size+1] = layo.item[i].image_ref.left & 0xFF;
		layo_data_size += 2;

		layo_data[layo_data_size] = (layo.item[i].image_ref.bottom >> 8) & 0xFF;
		layo_data[layo_data_size+1] = layo.item[i].image_ref.bottom & 0xFF;
		layo_data_size += 2;

		layo_data[layo_data_size] = (layo.item[i].image_ref.right >> 8) & 0xFF;
		layo_data[layo_data_size+1] = layo.item[i].image_ref.right & 0xFF;
		layo_data_size += 2;
		
		for(int j = 0; j < 4; j++) // Padding
		{
			layo_data[layo_data_size] = 0x00;
			layo_data_size++;
		}
		
		for(int j = 0; j < 4; j++) // for char resource type string
		{
			layo_data[layo_data_size] = layo.item[i].image_ref.resource_type[j];
			layo_data_size++;
		}
		
		layo_data[layo_data_size] = (layo.item[i].image_ref.resource_id >> 8) & 0xFF;
		layo_data[layo_data_size+1] = layo.item[i].image_ref.resource_id & 0xFF;
		layo_data_size += 2;
		
		layo_data[layo_data_size] = (layo.item[i].image_ref.image_alignment >> 8) & 0xFF;
		layo_data[layo_data_size+1] = layo.item[i].image_ref.image_alignment & 0xFF;
		layo_data_size += 2;
		
		layo_data[layo_data_size] = (layo.item[i].image_ref.image_index >> 8) & 0xFF;
		layo_data[layo_data_size+1] = layo.item[i].image_ref.image_index & 0xFF;
		layo_data_size += 2;
		
		for(int j = 0; j < 6; j++) // Padding
		{
			layo_data[layo_data_size] = 0x00;
			layo_data_size++;
		}
	}
	
	// Store the layo resource into the theme.
	store_rsrc_data("layo", layo_id, name, layo_data, &layo_data_size);
	// layos do NOT need tdat entries.
	
	return;
}
