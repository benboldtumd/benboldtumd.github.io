#ifndef RSRC_WRITE_H
#define RSRC_WRITE_H

#include <string>
using namespace std;

void rsrc_write_init(void);
void store_rsrc_data(string resource_type_string, signed int resource_id, string name, unsigned char *resource_data, unsigned int *resource_data_size);

#endif