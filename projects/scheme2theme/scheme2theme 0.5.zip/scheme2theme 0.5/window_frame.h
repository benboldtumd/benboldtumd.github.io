#ifndef WINDOW_FRAME_H
#define WINDOW_FRAME_H

void window_frame_init(void);
void window_frame_run(void);

#endif