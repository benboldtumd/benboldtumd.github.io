#ifndef CINF_H
#define CINF_H

#include "clr.h"

#include <string>
using namespace std;

typedef struct
{
	unsigned char corner_size;
	unsigned char side_thickness;
	unsigned char tile_sides;
	unsigned char pattern_anchor;
	signed short int background_pattern_id;
	signed short int background_pixel_y;
	signed short int background_pixel_x;
	signed short int text_pixel_y;
	signed short int text_pixel_x;
	signed short int embossing_pixel_y;  // Text embossing is not supported in themes!
	signed short int embossing_pixel_x;  // (2 separate text colors are not possible in one layo)
	unsigned short int transparency;  // Alpha transparency is not supported in themes!
} cinf_data_t;

typedef struct
{
	unsigned int corner_size;
	unsigned int side_thickness;
	signed int background_plut_id;
} cinf_result_t;

void cinf_init(void);
cinf_data_t cinf_get_data(signed int cinf_id);

cinf_result_t cinf_v_parse(signed int cinf_id, signed int pxm_id, string name, clr_color_t clr_color);
cinf_result_t cinf_h_parse(signed int cinf_id, signed int pxm_id, unsigned int height, string name, clr_color_t clr_color);
cinf_result_t cinf_vh_parse(signed int cinf_id, signed int pxm_id, string name, clr_color_t clr_color);
void cinf_calc_disabled_color(clr_color_t clr_color);

#endif