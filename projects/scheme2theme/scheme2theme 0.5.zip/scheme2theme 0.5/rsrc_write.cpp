#include "rsrc_write.h"

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

ofstream output_file;

void rsrc_write_init(void)
{
	output_file.open("output.c");
	return;
}

void store_rsrc_data(string resource_type_string, signed int resource_id, string name, unsigned char *resource_data, unsigned int *resource_data_size)
{	
	output_file << "data '" << resource_type_string << "' (" << dec << resource_id << ", \"" << name << "\") {\n";
	
	// Copy resource data.
	for(int i = 0; i < *resource_data_size; i++)
	{
		if( 0 == i % 16 )
		{
			output_file << "        $\"";
		}
		output_file << setw( 2 ) << setfill( '0' ) << hex << (unsigned int)resource_data[i];

		if(i != *resource_data_size - 1)  // Detect if this is the last byte.
		{
			if( (i > 0) && (0 == (i+1) % 16) )
			{
				output_file << "\"\n";
			}
			else if( 0 == (i+1) % 2 )
			{
				output_file << " ";
			}
		}
	}
	
	output_file << "\"\n};\n";
	
	return;
}
