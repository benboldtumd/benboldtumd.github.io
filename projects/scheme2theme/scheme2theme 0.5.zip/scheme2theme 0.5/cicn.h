#ifndef CICN_H
#define CICN_H

#include "clr.h"  // for rgb_color_t;

#include <string>
using namespace std;


void cicn_init(void);
void cicn_load_cicn(signed int cicn_id, unsigned int output_width, unsigned int output_height);

void add_new_pxm_index(void);

void cicn_store_opaque_mask(void);
void cicn_copy_image_pixel(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y);
void cicn_copy_mask_pixel(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y);
void cicn_copy_image_rectangle(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y, unsigned int width, unsigned int height);
void cicn_copy_mask_rectangle(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y, unsigned int width, unsigned int height);
void cicn_copy_image_and_mask_pixel(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y);
void cicn_copy_image_and_mask_rectangle(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y, unsigned int width, unsigned int height);

unsigned int cicn_get_source_width(void);
unsigned int cicn_get_source_height(void);

unsigned int cicn_predict_width(signed int cicn_id);
unsigned int cicn_predict_height(signed int cicn_id);

rgb_color_t cicn_get_pixel_color(unsigned int x, unsigned int y);

void cicn_store_pxm(signed int pxm_id, string name, bool single_mask);

#endif