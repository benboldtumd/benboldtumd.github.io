#include "window_frame.h"
#include "cicn.h"
#include "rsrc_read.h"
#include "clr.h"
#include "ppat.h"

#include <iostream>
using namespace std;

void window_frame_init(void)
{
	return;
}

void window_frame_default_document(signed int frame_id, signed int output_frame_id, clr_color_t text_clr_color, signed int racing_stripe_id, signed int output_racing_stripe_id)
{
	cicn_load_cicn(frame_id, 16, 16);
	
	// Build image 0 in pxm#: outer corners
	cicn_copy_image_and_mask_rectangle(0, 0, 0, 0, 4, 4);  // Top Left
	cicn_copy_image_and_mask_rectangle(12, 0, 12, 0, 4, 4);  // Top Right
	cicn_copy_image_and_mask_rectangle(0, 10, 0, 10, 6, 6);  // Bottom Left
	cicn_copy_image_and_mask_rectangle(10, 10, 10, 10, 6, 6);  // Bottom Right
	
	// Build image 1 in pxm#: outer top and bottom
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		cicn_copy_image_and_mask_rectangle(6, 0, i, 0, 1, 3);  // Top Edge
		cicn_copy_image_and_mask_rectangle(6, 10, i, 10, 1, 6);  // Bottom Edge
	}
	
	// Build image 2 in pxm#: outer left and right
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		cicn_copy_image_and_mask_rectangle(0, 6, 0, i, 6, 1);  // Left Edge
		cicn_copy_image_and_mask_rectangle(10, 6, 10, i, 6, 1);  // Right Edge
	}
	
	// Build image 3 in pxm#: inner corners and inner top edge
	add_new_pxm_index();
	cicn_copy_image_and_mask_rectangle(4, 3, 0, 0, 2, 3);  // Left Inner Corner
	cicn_copy_image_and_mask_rectangle(10, 3, 14, 0, 2, 3);  // Right Inner Corner
	for(int i = 0; i < 16; i++)  // Inner Top Edge (stored on bottom of image)
	{
		cicn_copy_image_and_mask_rectangle(6, 4, i, 14, 1, 2);
	}
	
	// Build image 4 in pxm#: Title Bar Color
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		for(int j = 0; j < 16; j++)
		{
			cicn_copy_image_and_mask_pixel(6, 3, i, j);
		}
	}
	
	// Build image 5 in pxm#: Shadow Color
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		for(int j = 0; j < 16; j++)
		{
			cicn_copy_image_and_mask_pixel(0, 0, i, j);
		}
	}
	
	// Title Text Color.
	modify_clr_entry(text_clr_color, cicn_get_pixel_color(7, 3));
	
	// Go ahead and store the titlebar background color into these variables right here.
	rgb_color_t racing_stripes_plut_color = cicn_get_pixel_color(6, 3);
	
	cicn_store_pxm(output_frame_id, false);  // Separate masks.
	
	// Build racing stripes into new pxm# resource.
	if(0 != racing_stripe_id)
	{
		cicn_load_cicn(racing_stripe_id, 8, 13);
		
		// Left cap
		cicn_copy_image_and_mask_rectangle(0, 0, 0, 0, 8, 13);
		
		// Right cap
		add_new_pxm_index();
		cicn_copy_image_and_mask_rectangle(9, 0, 1, 0, 7, 13);
		
		// Horizontal Stretch
		add_new_pxm_index();
		for(int i = 0; i < 8; i++)
		{
			cicn_copy_image_and_mask_rectangle(8, 0, i, 0, 1, 13);  // Fill
		}
		
		cicn_store_pxm(output_racing_stripe_id, false);  // Separate masks.
	}
	
	// Check for racing stripe PPAT and copy if found.
	ppat_copy(racing_stripe_id, racing_stripes_plut_color);
}

void window_frame_default_modal(signed int frame_id, signed int output_frame_id, clr_color_t text_clr_color, signed int racing_stripe_id, signed int output_racing_stripe_id)
{
	cicn_load_cicn(frame_id, 16, 16);
	
	// Build image 0 in pxm#: Title Bar Corners
	cicn_copy_image_and_mask_rectangle(0, 0, 0, 0, 4, 4);  // Top Left
	cicn_copy_image_and_mask_rectangle(12, 0, 12, 0, 4, 4);  // Top Right
	cicn_copy_image_and_mask_rectangle(0, 12, 0, 13, 4, 3);  // Bottom Left
	cicn_copy_image_and_mask_rectangle(12, 12, 12, 13, 4, 3);  // Bottom Right
	
	// Build image 1 in pxm#: Title Bar top and bottom edges
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		cicn_copy_image_and_mask_rectangle(6, 0, i, 0, 1, 3);  // Top Edge
		cicn_copy_image_and_mask_rectangle(6, 13, i, 14, 1, 2);  // Bottom Edge
	}
	
	// Build image 2 in pxm#: Title Bar left and right edges
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		cicn_copy_image_and_mask_rectangle(0, 6, 0, i, 4, 1);  // Left Edge
		cicn_copy_image_and_mask_rectangle(12, 6, 12, i, 4, 1);  // Right Edge
	}
	
	// Build image 3 in pxm#: Title Bar Color
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		for(int j = 0; j < 16; j++)
		{
			cicn_copy_image_and_mask_pixel(6, 3, i, j);
		}
	}
	
	// Build image 4 in pxm#: lower corners
	add_new_pxm_index();
	cicn_copy_image_and_mask_rectangle(5, 5, 0, 0, 3, 3);  // Top Left
	cicn_copy_image_and_mask_rectangle(8, 5, 13, 0, 3, 3);  // Top Right
	cicn_copy_image_and_mask_rectangle(5, 8, 0, 13, 3, 3);  // Bottom Left
	cicn_copy_image_and_mask_rectangle(8, 8, 13, 13, 3, 3);  // Bottom Right
	
	// Build image 5 in pxm#: lower top and bottom edges
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		cicn_copy_image_and_mask_rectangle(7, 5, i, 0, 1, 3);  // Top Edge
		cicn_copy_image_and_mask_rectangle(8, 8, i, 13, 1, 3);  // Bottom Edge
	}
	
	// Build image 6 in pxm#: lower left and right edges
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		cicn_copy_image_and_mask_rectangle(5, 7, 0, i, 3, 1);  // Left Edge
		cicn_copy_image_and_mask_rectangle(8, 8, 13, i, 3, 1);  // Right Edge
	}
	
	// Build image 7 in pxm#: Shadow Color
	add_new_pxm_index();
	for(int i = 0; i < 16; i++)
	{
		for(int j = 0; j < 16; j++)
		{
			cicn_copy_image_and_mask_pixel(0, 0, i, j);
		}
	}
	
	// Title Text Color.
	modify_clr_entry(text_clr_color, cicn_get_pixel_color(7, 3));
	
	// Go ahead and store the titlebar background color into these variables right here.
	rgb_color_t racing_stripes_plut_color = cicn_get_pixel_color(6, 3);
	
	cicn_store_pxm(output_frame_id, false);  // Separate masks.
	
	// Build racing stripes into new pxm# resource.
	if(0 != racing_stripe_id)
	{
		cicn_load_cicn(racing_stripe_id, 8, 13);
		
		// Left cap
		cicn_copy_image_and_mask_rectangle(0, 0, 0, 0, 8, 13);
		
		// Right cap
		add_new_pxm_index();
		cicn_copy_image_and_mask_rectangle(9, 0, 1, 0, 7, 13);
		
		// Horizontal Stretch
		add_new_pxm_index();
		for(int i = 0; i < 8; i++)
		{
			cicn_copy_image_and_mask_rectangle(8, 0, i, 0, 1, 13);  // Fill
		}
		
		cicn_store_pxm(output_racing_stripe_id, false);  // Separate masks.
	}
	
	// Check for racing stripe PPAT and copy if found.
	ppat_copy(racing_stripe_id, racing_stripes_plut_color);
}

void window_frame_run(void)
{
	// ** Document Window Frame **
	// First detect if this frame uses a wnd# resource.
	if(resource_exists("wnd#", -14332))
	{
		// Handle wnd# parsing here.
		cerr << "wnd# resources are not supported!\n";
	}
	else
	{
		// This frame does not use a wnd# resource.
		
		// * Active elements
		// Convert grow box.
		cicn_load_cicn(-14330, 21, 21);  // Though the original image may be smaller, the mask should be clear for the extra space.
		cicn_copy_image_and_mask_rectangle(0, 0, 0, 0, cicn_get_source_width(), cicn_get_source_height());
		cicn_store_pxm(1282, true);
		
		// Convert the rest of the frame.
		window_frame_default_document(-14332, 1280, CLR_DOCUMENT_WINDOW_TITLE_ACTIVE_TEXT_COLOR, -14331, 1281);
		
		// * Inactive Elements
		// Convert grow box.
		cicn_load_cicn(-14334, 21, 21);  // Though the original image may be smaller, the mask should be clear for the extra space.
		cicn_copy_image_and_mask_rectangle(0, 0, 0, 0, cicn_get_source_width(), cicn_get_source_height());
		cicn_store_pxm(1292, true);
		
		// Convert the rest of the frame.
		window_frame_default_document(-14336, 1290, CLR_DOCUMENT_WINDOW_TITLE_INACTIVE_TEXT_COLOR, 0, 1291);
	}
	
	// ** Dialog Box Frame **
	// First detect if this frame uses a wnd# resource.
	if(resource_exists("wnd#", -14328))
	{
		// Handle wnd# parsing here.
		cerr << "wnd# resources are not supported!\n";
	}
	else
	{
		// This frame does not use a wnd# resource.
		
		// * Active elements
		window_frame_default_modal(-14326, 1340, CLR_MOVABLE_MODAL_WINDOW_TITLE_ACTIVE_TEXT_COLOR, -14325, 1341);
		
		// * Inactive Elements
		// Convert the rest of the frame.
		window_frame_default_modal(-14328, 1350, CLR_MOVABLE_MODAL_WINDOW_TITLE_INACTIVE_TEXT_COLOR, 0, 1351);
	}
	
	// ** Alert Window Frame **
		// First detect if this frame uses a wnd# resource.
	if(resource_exists("wnd#", -14328))
	{
		// Handle wnd# parsing here.
		cerr << "wnd# resources are not supported!\n";
	}
	else
	{
		// This frame does not use a wnd# resource.
		
		// * Active elements
		window_frame_default_modal(-14322, 1420, CLR_NONE, -14321, 1421);
		
		// * Inactive Elements
		// Convert the rest of the frame.
		window_frame_default_modal(-14324, 1430, CLR_NONE, 0, 1431);
	}
	
	return;
}