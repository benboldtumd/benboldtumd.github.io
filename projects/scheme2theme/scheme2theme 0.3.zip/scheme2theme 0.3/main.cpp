#include <iostream>
#include <string>
#include <fstream>
using namespace std;

#include "rsrc_read.h"
#include "rsrc_write.h"
#include "tdat.h"
#include "system_clut.h"
#include "plut.h"
#include "clr.h"
#include "window_frame.h"
#include "ics.h"
#include "dctb.h"

int main (int argc, char * const argv[]) {
	/*	if(argc < 2)
{
		cout << "Please supply the path to a Kaleidoscope Scheme as an argument.\n";
		return 0;
}

cout << argv[1] << endl;
string filename = argv[1];
filename.append("/rsrc");

rsrc_read_init(filename.c_str());
*/
	cout << "\nParsing Resource fork...\n\n";
	
	if(rsrc_read_init("Onyx/rsrc"))
	{
		return 1;  // Exit program if scheme file could not be opened.
	}
	
	cout << "Initializing converter modules...\n";
	
	rsrc_write_init();
	tdat_init();
	plut_init();
	clr_init();	
	ics_init();
	window_frame_init();
	dctb_init();
	
	cout << "Converting window widgets from ics8 to pxm#...\n";
	ics_run();
	
	cout << "Converting window frames from cicn to pxm#...\n";
	window_frame_run();
	
	dctb_run();
	
	plut_run();
	
	cout << "Storing additional resources...\n\n";
	// Store system clut for icl8 conversion.
	make_system_clut();
	
	// store tic# resource
	store_clr_resource();
	
	// Store plut resources
	store_required_plut_resource();
	store_user_plut_resource();
	
	// Store tdat resource:
	store_tdat_resource();

	cout << "Scheme to Theme Conversion Complete!\n";
	
	return 0;
}
