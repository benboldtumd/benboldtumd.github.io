#ifndef DCTB_H
#define DCTB_H

void dctb_init(void);
void dctb_run(void);

#endif