#ifndef PPAT_H
#define PPAT_H

#include "clr.h"  // for rgb_color_t

unsigned int ppat_copy(signed int ppat_id, rgb_color_t rgb_color);

#endif