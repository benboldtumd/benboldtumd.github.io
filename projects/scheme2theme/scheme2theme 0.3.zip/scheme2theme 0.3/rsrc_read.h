#ifndef RSRC_READ_H
#define RSRC_READ_H

#include <string>
using namespace std;

int rsrc_read_init(const char* filename);
bool get_resource_data(string resource_type_string, signed int resource_id, unsigned char **resource_data, unsigned int *resource_data_size);
bool resource_exists(string resource_type_string, signed int resource_id);

#endif