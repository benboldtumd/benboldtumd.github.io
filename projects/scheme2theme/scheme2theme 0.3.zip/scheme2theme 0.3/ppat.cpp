#include "ppat.h"
#include "rsrc_read.h"
#include "rsrc_write.h"
#include "tdat.h"
#include "plut.h"

unsigned char* resource_data;
unsigned int resource_data_size;

unsigned int ppat_copy(signed int ppat_id, rgb_color_t rgb_color)
{
	resource_data = new unsigned char[10240];
	if(0 != ppat_id && resource_exists("ppat", ppat_id))
	{
		get_resource_data("ppat", ppat_id, &resource_data, &resource_data_size);
		store_rsrc_data("ppat", ppat_id, resource_data, &resource_data_size);
		tdat_add_entry("ppat", ppat_id);  // All image resources must be referenced in the tdat resource.	
	}
	else
	{
		ppat_id = 0;  // Indicate that there is no ppat.
	}
	return add_user_plut_entry(ppat_id, rgb_color);
}