#include "cicn.h"
#include "rsrc_read.h"
#include "rsrc_write.h"
#include "tdat.h"

#include <iostream>
using namespace std;

#define MAX_CANVAS_SIZE 10240
#define MAX_PXM_INDEX 32


typedef struct
{
	unsigned int image_trimmed_width;  // visible width of image
	
	unsigned int image_row_bytes;  // untrimmed width (bytes)
	unsigned int image_row_count;  // i.e. height in pixels
	unsigned int image_bit_depth;
	unsigned int mask_row_bytes;  // untrimmed width (bytes)
	unsigned int mask_row_count;
	unsigned int one_bit_row_bytes;  // untrimmed width (bytes)
	unsigned int one_bit_row_count;	
} cicn_image_info_t;

typedef struct
{
	unsigned char data[MAX_CANVAS_SIZE];
	unsigned int data_size;
} cicn_data_t;

static struct
{
	unsigned char* resource_data;
	unsigned int resource_data_size;
	
	unsigned char output_data[MAX_CANVAS_SIZE];
	unsigned int output_data_size;
	
	cicn_data_t	clut;
	
	cicn_image_info_t cicn_info;
	cicn_data_t cicn_mask;
	cicn_data_t cicn_image;
	
	cicn_image_info_t pxm_info;
	cicn_data_t pxm_mask[MAX_PXM_INDEX];
	cicn_data_t pxm_image[MAX_PXM_INDEX];
	
	unsigned int current_pxm_index;
} cicn;


void cicn_init(void)
{
	return;
}

void clear_new_pxm_index(void)
{
	// Clear image canvas at new index.
	cicn.pxm_image[cicn.current_pxm_index].data_size = 0;
	for(int i = 0; i < cicn.pxm_info.image_row_count * cicn.pxm_info.image_row_bytes; i++)
	{
		cicn.pxm_image[cicn.current_pxm_index].data[i] = 0;
		cicn.pxm_image[cicn.current_pxm_index].data_size++;
	}
	
	// Clear mask canvas at new index.
	// The program goes ahead and builds masks for each pxm# image but they can be thrown out at the end if you want to use a single mask for the pxm#.
	cicn.pxm_mask[cicn.current_pxm_index].data_size = 0;
	for(int i = 0; i < cicn.pxm_info.mask_row_count * cicn.pxm_info.mask_row_bytes; i++)
	{
		cicn.pxm_mask[cicn.current_pxm_index].data[i] = 0;
		cicn.pxm_mask[cicn.current_pxm_index].data_size++;
	}
}

void add_new_pxm_index(void)
{
	if(MAX_PXM_INDEX == cicn.current_pxm_index)
	{
		cerr << "Maximum number of pxm# image indexes was exceeded!  Please update MAX_PXM_INDEX to a larger number.\n";
	}
	else
	{
		cicn.current_pxm_index++;
		clear_new_pxm_index();
	}
}

// Prepares the canvas onto which pxm# data can be written.
void cicn_init_canvas(unsigned int width, unsigned int height)
{
	// Currently, pxm# depth must equal the original cicn depth.
	cicn.pxm_info.image_bit_depth = cicn.cicn_info.image_bit_depth;
	
	// Image Height
	cicn.pxm_info.image_row_count = height;
	
	// Image Width
	cicn.pxm_info.image_trimmed_width = width;  // trimmed
	
	// Calculate proper image padding based on trimmed width.
	unsigned int row_bytes;
	row_bytes = (cicn.cicn_info.image_bit_depth * width) / 8;
	if((cicn.cicn_info.image_bit_depth * width) % 8 != 0)
	{
		row_bytes++;  // Round up to the next full byte if necessary.
	}
	if(row_bytes % 2 != 0)
	{
		row_bytes++;  // Round up the number of bytes to the nearest full 2 byte word if necessary.
	}
	
	cicn.pxm_info.image_row_bytes = row_bytes;  // untrimmed, rounded up to the nearest 2 bytes (considering bit depth)
	
	// Mask Height
	cicn.pxm_info.mask_row_count = height;
	
	// Mask Width
	// cicn.pxm_info.mask_trimmed_width = width;  // use Image trimmed width, must be the same.
	
	// Calculate proper mask padding based on trimmed width.
	row_bytes = width / 8;
	if(width % 8 != 0)
	{
		row_bytes++;  // Round up to the next full byte if necessary.
	}
	if(row_bytes % 2 != 0)
	{
		row_bytes++;  // Round up the number of bytes to the nearest full 2 byte word if necessary.
	}
	
	cicn.pxm_info.mask_row_bytes = row_bytes;  // untrimmed, rounded up to the nearest 2 bytes (considering bit depth)
	
	// 1-bit images are not used in pxm#.
	cicn.pxm_info.one_bit_row_bytes = 0;
	cicn.pxm_info.one_bit_row_count = 0;	
	
	// Start with pxm# index 0.
	cicn.current_pxm_index = 0;
	
	// Clear image canvas for this index, index 0.
	clear_new_pxm_index();
	
	return;
}

// Loads data into local structures for easy manipulation with little regard for memory management.
void cicn_load_cicn(signed int cicn_id, unsigned int output_width, unsigned int output_height)
{
	if(get_resource_data("cicn", cicn_id, &cicn.resource_data, &cicn.resource_data_size))
	{
		//In image bounds, I am assuming that top and left are 0 for image, mask, and 1-bit versions.
		cicn.cicn_info.image_row_bytes = (cicn.resource_data[4] << 8 | cicn.resource_data[5]) & 0x1FFF;  // Use only bits 0 (lsb) to 12
		cicn.cicn_info.image_row_count = (cicn.resource_data[10] << 8 | cicn.resource_data[11]);  // Height
		cicn.cicn_info.image_trimmed_width = (cicn.resource_data[12] << 8 | cicn.resource_data[13]);  // Width considering removal of padding
		cicn.cicn_info.image_bit_depth = (cicn.resource_data[32] << 8 | cicn.resource_data[33]);
		cicn.cicn_info.mask_row_bytes = (cicn.resource_data[52] << 24 | cicn.resource_data[53] << 16 | cicn.resource_data[54] << 8 | cicn.resource_data[55]);
		cicn.cicn_info.mask_row_count = (cicn.resource_data[60] << 8 | cicn.resource_data[61]);
		cicn.cicn_info.one_bit_row_bytes = (cicn.resource_data[66] << 24 | cicn.resource_data[67] << 16 | cicn.resource_data[68] << 8 | cicn.resource_data[69]);
		cicn.cicn_info.one_bit_row_count = (cicn.resource_data[74] << 8 | cicn.resource_data[75]);
		
		// Locate color table in cicn.
		unsigned int color_table_start;
		unsigned int color_table_end;
		
		color_table_start = 0x52 + (cicn.cicn_info.mask_row_bytes * cicn.cicn_info.image_row_count) + (cicn.cicn_info.one_bit_row_bytes * cicn.cicn_info.one_bit_row_count) + 6;
		color_table_end = color_table_start + 2 + ((cicn.resource_data[color_table_start] << 8 | cicn.resource_data[color_table_start+1]) + 1) * 8;
		
		// Copy color table into local structures.
		cicn.clut.data_size = 0;
		
		for(int i = 0; i < 6; i++)
		{
			cicn.clut.data[i] = 0;  // clut header
			cicn.clut.data_size++;
		}
		for(int i = color_table_start; i < color_table_end; i++)
		{
			cicn.clut.data[cicn.clut.data_size] = (unsigned int)cicn.resource_data[i];
			cicn.clut.data_size++;
		}
				
		// Copy cicn mask data into local structures.
		cicn.cicn_mask.data_size = cicn.cicn_info.mask_row_bytes * cicn.cicn_info.mask_row_count;
		for(int i = 0; i < cicn.cicn_mask.data_size; i++)
		{
			cicn.cicn_mask.data[i] = cicn.resource_data[0x52 + i];
		}
		
		// Copy cicn image data into local structures.
		for(int i = 0; i < cicn.cicn_info.image_row_bytes * cicn.cicn_info.image_row_count; i++)
		{
			cicn.cicn_image.data[i] = cicn.resource_data[color_table_end + i];
		}

		// Prepare the pxm# canvas.
		cicn_init_canvas(output_width, output_height);
	}
	return;
}

void cicn_store_opaque_mask(void)
{
	for(int i = 0; i < cicn.pxm_info.mask_row_count * cicn.pxm_info.mask_row_bytes; i++)
	{
		cicn.pxm_mask[cicn.current_pxm_index].data[i] = 0xFF;  // 0xFF means opaque regardless of depth.
	}		
}

void cicn_copy_image_pixel(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y)
{
	unsigned int source_pixel_row_byte;
	unsigned int source_pixel_location_in_byte;
	unsigned int pixel_value;
	unsigned int pixel_mask;
	
	unsigned int dest_pixel_row_byte;
	unsigned int dest_pixel_location_in_byte;
	unsigned int dest_pixel_index;
	
	// bytes per pixel = depth / 8.
	
	// ** Retrieve pixel form cicn data. **
	
	// Find how many bytes into a row is the byte where this pixel resides.
	source_pixel_row_byte = (cicn.cicn_info.image_bit_depth * source_x) / 8;
	// Calculate how many bits from MSB within the byte where the actual pixel is located.
	source_pixel_location_in_byte = ((cicn.cicn_info.image_bit_depth * source_x) % 8);
	
	// Record the whole byte considering the offset from all of the rows above it.
	pixel_value = cicn.cicn_image.data[(source_y * cicn.cicn_info.image_row_bytes) + source_pixel_row_byte];
	
	// Calculate a mask of 1s on the LSB end and store in pixel_mask.
	pixel_mask = (1 << cicn.cicn_info.image_bit_depth) - 1;
	
	// Shift the pixel_value so that the actual pixel data is straight under the mask.
	pixel_value >>= ((8 - cicn.cicn_info.image_bit_depth) - source_pixel_location_in_byte);
	
	// Mask out the pixel with this mask.
	pixel_value &= pixel_mask;
	
	// ** Store pixel in pxm# data. **
	
	// Find how many bytes into a row is the byte where this pixel resides.
	dest_pixel_row_byte = (cicn.pxm_info.image_bit_depth * dest_x) / 8;

	// Calculate how many bits from MSB within the byte where the actual pixel is located.
	dest_pixel_location_in_byte = ((cicn.pxm_info.image_bit_depth * dest_x) % 8);

	// Calculate a mask of 1s on the LSB end and store in pixel_mask.
	pixel_mask = (1 << cicn.pxm_info.image_bit_depth) - 1;
	
	// Shift the mask and pixel to go on top of the destination area.
	pixel_value <<= ((8 - cicn.pxm_info.image_bit_depth) - dest_pixel_location_in_byte);
	pixel_mask  <<= ((8 - cicn.pxm_info.image_bit_depth) - dest_pixel_location_in_byte);
	
	// Find the index of the destination pixel's byte
	dest_pixel_index = (dest_y * cicn.pxm_info.image_row_bytes) + dest_pixel_row_byte;
	
	// Clear the bits that this mask is covering.
	cicn.pxm_image[cicn.current_pxm_index].data[dest_pixel_index] &= ~(pixel_mask);
	
	// OR in the new bits for this pixel.
	cicn.pxm_image[cicn.current_pxm_index].data[dest_pixel_index] |= pixel_value;	
}

void cicn_copy_mask_pixel(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y)
{
	unsigned int source_pixel_row_byte;
	unsigned int source_pixel_location_in_byte;
	unsigned int pixel_value;
	unsigned int pixel_mask;
	
	unsigned int dest_pixel_row_byte;
	unsigned int dest_pixel_location_in_byte;
	unsigned int dest_pixel_index;
	
	// bytes per pixel = depth / 8.
	
	// ** Retrieve pixel form cicn data. **
	
	// Find how many bytes into a row is the byte where this pixel resides.
	source_pixel_row_byte =  source_x / 8;
	// Calculate how many bits from MSB within the byte where the actual pixel is located.
	source_pixel_location_in_byte = source_x % 8;
	
	// Record the whole byte considering the offset from all of the rows above it.
	pixel_value = cicn.cicn_mask.data[(source_y * cicn.cicn_info.mask_row_bytes) + source_pixel_row_byte];
	
	// Calculate a mask of 1s on the LSB end and store in pixel_mask.
	pixel_mask = 1;
	
	// Shift the pixel_value so that the actual pixel data is straight under the mask.
	pixel_value >>= (7 - source_pixel_location_in_byte);
	
	// Mask out the pixel with this mask.
	pixel_value &= pixel_mask;
	
	// ** Store pixel in pxm# data. **
	
	// Find how many bytes into a row is the byte where this pixel resides.
	dest_pixel_row_byte = dest_x / 8;
	
	// Calculate how many bits from MSB within the byte where the actual pixel is located.
	dest_pixel_location_in_byte = dest_x % 8;
	
	// Calculate a mask of 1s on the LSB end and store in pixel_mask.
	pixel_mask = 1;
	
	// Shift the mask and pixel to go on top of the destination area.
	pixel_value <<= (7 - dest_pixel_location_in_byte);
	pixel_mask  <<= (7 - dest_pixel_location_in_byte);
	
	// Find the index of the destination pixel's byte
	dest_pixel_index = (dest_y * cicn.pxm_info.mask_row_bytes) + dest_pixel_row_byte;
	
	// Clear the bits that this mask is covering.
	cicn.pxm_mask[cicn.current_pxm_index].data[dest_pixel_index] &= ~(pixel_mask);
	
	// OR in the new bits for this pixel.
	cicn.pxm_mask[cicn.current_pxm_index].data[dest_pixel_index] |= pixel_value;		
}

void cicn_copy_image_rectangle(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y, unsigned int width, unsigned int height)
{
	for(int i = 0; i < width; i++)
	{
		for(int j = 0; j < height; j++)
		{
			cicn_copy_image_pixel(source_x + i, source_y + j, dest_x + i, dest_y + j);
		}
	}	
}

void cicn_copy_mask_rectangle(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y, unsigned int width, unsigned int height)
{
	for(int i = 0; i < width; i++)
	{
		for(int j = 0; j < height; j++)
		{
			cicn_copy_mask_pixel(source_x + i, source_y + j, dest_x + i, dest_y + j);
		}
	}	
}

void cicn_copy_image_and_mask_pixel(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y)
{
	cicn_copy_image_pixel(source_x, source_y, dest_x, dest_y);
	cicn_copy_mask_pixel(source_x, source_y, dest_x, dest_y);
}

void cicn_copy_image_and_mask_rectangle(unsigned int source_x, unsigned int source_y, unsigned int dest_x, unsigned int dest_y, unsigned int width, unsigned int height)
{
	cicn_copy_image_rectangle(source_x, source_y, dest_x, dest_y, width, height);
	cicn_copy_mask_rectangle(source_x, source_y, dest_x, dest_y, width, height);
}

unsigned int cicn_get_source_width(void)
{
	return cicn.cicn_info.image_trimmed_width;
}

unsigned int cicn_get_source_height(void)
{
	return cicn.cicn_info.image_row_count;
}

rgb_color_t cicn_get_pixel_color(unsigned int x, unsigned int y)
{
	rgb_color_t rgb_color;
	unsigned int pixel_value;
	unsigned int pixel_mask;
	unsigned int pixel_location_in_byte;

	// Find the entire byte in which this pixel is stored.
	pixel_value = cicn.cicn_image.data[( (x * cicn.cicn_info.image_bit_depth) / 8 ) + ( y * cicn.cicn_info.image_row_bytes )];
	
	// Calculate how many bits from MSB within the byte where the actual pixel is located.
	pixel_location_in_byte = ((x * cicn.cicn_info.image_bit_depth) % 8);

	// Calculate a mask of 1s on the LSB end and store in pixel_mask.
	pixel_mask = (1 << cicn.cicn_info.image_bit_depth) - 1;
	
	// Shift the pixel_value so that the actual pixel data is straight under the mask.
	pixel_value >>= ((8 - cicn.cicn_info.image_bit_depth) - pixel_location_in_byte);
	
	// Mask out the pixel with this mask.
	pixel_value &= pixel_mask;

	// Search for this pixel value in the color table.
	for(int i = 8; i < cicn.clut.data_size; i += 8)
	{
		if( (cicn.clut.data[i] == (pixel_value >> 8) & 0xFF) && (cicn.clut.data[i+1] == pixel_value & 0xFF) )
		{
			rgb_color.red =   (cicn.clut.data[i+2] << 8) | cicn.clut.data[i+3];
			rgb_color.green = (cicn.clut.data[i+4] << 8) | cicn.clut.data[i+5];
			rgb_color.blue =  (cicn.clut.data[i+6] << 8) | cicn.clut.data[i+7];
			return rgb_color;
		}
	}
	
	// Deplorable Failure Mode.
	rgb_color.red =   0xFFFF;
	rgb_color.green = 0x0000;
	rgb_color.blue =  0x0000;
	
	return rgb_color;
}

void cicn_store_pxm(signed int pxm_id, bool single_mask)
{
	// Store the clut color table into the theme.
	store_rsrc_data("clut", pxm_id, cicn.clut.data, &cicn.clut.data_size);
	tdat_add_entry("clut", pxm_id);  // All image resources must be referenced in the tdat resource.
	
	// Build pxm# header
	cicn.output_data[0]  = 0x00, cicn.output_data[1] = 0x01; // Mac OS 8	
	if(single_mask) // Mask Mode 0x0001 = single, 0x0000 = separate mask for each image.
	{
		cicn.output_data[2] = 0x00, cicn.output_data[3] = 0x01;
	}
	else
	{
		cicn.output_data[2] = 0x00, cicn.output_data[3] = 0x00;
	}
	cicn.output_data[4]  = 0x00, cicn.output_data[5] = 0x00; // Top Bound (always assumed 0)
	cicn.output_data[6]  = 0x00, cicn.output_data[7] = 0x00; // Left Bound (always assumed 0)
	cicn.output_data[8]  = ((cicn.pxm_info.image_row_count >> 8) & 0xFF), cicn.output_data[9] = (cicn.pxm_info.image_row_count & 0xFF); // Bottom Bound, aka height
	cicn.output_data[10] = ((cicn.pxm_info.image_trimmed_width >> 8) & 0xFF), cicn.output_data[11] = (cicn.pxm_info.image_trimmed_width & 0xFF); // Trimmed Width
	cicn.output_data[12] = 0x00, cicn.output_data[13] = (cicn.pxm_info.image_bit_depth & 0xFF); // Bit Depth
	cicn.output_data[14] = 0x00, cicn.output_data[15] = 0x08; // Pixel Type = Indexed
	cicn.output_data[16] = 0x00, cicn.output_data[17] = 0x00, cicn.output_data[18] = 0x00, cicn.output_data[19] = 0x00; // Unknown
	cicn.output_data[20] = ((pxm_id >> 8) & 0xFF), cicn.output_data[21] = (pxm_id & 0xFF); // clut resource ID matches pxm# ID for simplicity.
	cicn.output_data[22] = (((cicn.current_pxm_index + 1) >> 8) & 0xFF), cicn.output_data[23] = ((cicn.current_pxm_index + 1) & 0xFF); // Image count
	
	cicn.output_data_size = 24;  // Update size for the above data.
	
	// Copy single or multiple masks.
	for(int i = 0; i < cicn.pxm_mask[0].data_size; i++)
	{
		cicn.output_data[cicn.output_data_size] = cicn.pxm_mask[0].data[i];
		cicn.output_data_size++;
	}
	if(!single_mask)  // If multiple masks is selected, copy all the rest of the masks.
	{
		for(int i = 1; i <= cicn.current_pxm_index; i++)
		{
			for(int j = 0; j < cicn.pxm_mask[i].data_size; j++)
			{
				cicn.output_data[cicn.output_data_size] = cicn.pxm_mask[i].data[j];
				cicn.output_data_size++;
			}
		}
	}
	
	// Copy Image data.
	for(int i = 0; i <= cicn.current_pxm_index; i++)
	{
		for(int j = 0; j < cicn.pxm_image[i].data_size; j++)
		{
			cicn.output_data[cicn.output_data_size] = cicn.pxm_image[i].data[j];
			cicn.output_data_size++;
		}
	}
	
	// Store the pxm# image resource into the theme.
	store_rsrc_data("pxm#", pxm_id, cicn.output_data, &cicn.output_data_size);
	tdat_add_entry("pxm#", pxm_id);  // All image resources must be referenced in the tdat resource.	
}


