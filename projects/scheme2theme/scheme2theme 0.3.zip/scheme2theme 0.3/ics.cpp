#include "ics.h"
#include "rsrc_read.h"
#include "rsrc_write.h"
#include "tdat.h"

typedef struct
{
	unsigned int unpressed_id;
	unsigned int pressed_id;
	unsigned int pixmap_id;
	unsigned int repetitions;
} widget_conversion_data_t;

unsigned char* resource_data;
unsigned int resource_data_size;

// Area to build a new resource
unsigned char pixmap_data[10240]; // 10 kib
unsigned int pixmap_size;

// Convert window widget icons into pxm# format.
widget_conversion_data_t widget_conversion_data[6];

void ics_init(void)
{
	widget_conversion_data[0].unpressed_id = -14336; // Large Close
	widget_conversion_data[0].pressed_id   = -14333;
	widget_conversion_data[0].pixmap_id    = 200;
	widget_conversion_data[0].repetitions  = 1;
	widget_conversion_data[1].unpressed_id = -14335; // Large Collapse
	widget_conversion_data[1].pressed_id   = -14332;
	widget_conversion_data[1].pixmap_id    = 210;
	widget_conversion_data[1].repetitions  = 1;
	widget_conversion_data[2].unpressed_id = -14334; // Large Zoom
	widget_conversion_data[2].pressed_id   = -14331;
	widget_conversion_data[2].pixmap_id    = 220;
	widget_conversion_data[2].repetitions  = 3;
	widget_conversion_data[3].unpressed_id = -14320; // Small Close
	widget_conversion_data[3].pressed_id   = -14317;
	widget_conversion_data[3].pixmap_id    = 201;
	widget_conversion_data[3].repetitions  = 1;
	widget_conversion_data[4].unpressed_id = -14319; // Small Collapse
	widget_conversion_data[4].pressed_id   = -14316;
	widget_conversion_data[4].pixmap_id    = 211;
	widget_conversion_data[4].repetitions  = 1;
	widget_conversion_data[5].unpressed_id = -14318; // Small Zoom
	widget_conversion_data[5].pressed_id   = -14315;
	widget_conversion_data[5].pixmap_id    = 221;
	widget_conversion_data[5].repetitions  = 3;
}

void widget_convert(signed int unpressed_id, signed int pressed_id, unsigned int repetitions, signed int output_id)
{
	// Build pxm# Header.	
	pixmap_data[0] = 0x00, pixmap_data[1] = 0x01; // Mac OS 8
	pixmap_data[2] = 0x00, pixmap_data[3] = 0x01; // Single Mask Mode
	pixmap_data[4] = 0x00, pixmap_data[5] = 0x00; // Top Bound
	pixmap_data[6] = 0x00, pixmap_data[7] = 0x00; // Left Bound
	pixmap_data[8] = 0x00, pixmap_data[9] = 0x10; // Bottom Bound
	pixmap_data[10] = 0x00, pixmap_data[11] = 0x10; // Right Bound
	pixmap_data[12] = 0x00, pixmap_data[13] = 0x08; // Bit Depth = 8
	pixmap_data[14] = 0x00, pixmap_data[15] = 0x08; // Pixel Type = Indexed
	pixmap_data[16] = 0x00, pixmap_data[17] = 0x00, pixmap_data[18] = 0x00, pixmap_data[19] = 0x00; // Unknown
	pixmap_data[20] = 0x00, pixmap_data[21] = 0x80; // clut resource ID = 128
	pixmap_data[22] = 0x00, pixmap_data[23] = 2 * repetitions; // Image count = 2 * # of repetitions
	
	pixmap_size = 24;  // Update size for the above data.
	
	if(get_resource_data("ics#", unpressed_id, &resource_data, &resource_data_size) && resource_data_size >= 0x40)
	{
		// Copy Mask into pixmap.
		for(int i = 0x20; i < 0x40; i++)
		{
			pixmap_data[pixmap_size] = resource_data[i];
			(pixmap_size)++;
		}
	}
	else return;
	
	for(int i = 0; i < repetitions; i++)
	{
		if(get_resource_data("ics8", unpressed_id, &resource_data, &resource_data_size) && resource_data_size >= 0x100)
		{
			// Copy unpressed image into pixmap.
			for(int i = 0x00; i < 0x100; i++)
			{
				pixmap_data[pixmap_size] = resource_data[i];
				(pixmap_size)++;
			}
		}
		else return;
		
		if(get_resource_data("ics8", pressed_id, &resource_data, &resource_data_size) && resource_data_size >= 0x100)
		{
			// Copy unpressed image into pixmap.
			for(int i = 0x00; i < 0x100; i++)
			{
				pixmap_data[pixmap_size] = resource_data[i];
				(pixmap_size)++;
			}
		}
		else return;
	}
	
	store_rsrc_data("pxm#", output_id, pixmap_data, &pixmap_size);
	tdat_add_entry("pxm#", output_id);
	
	return;
}

void ics_run(void)
{
	for(int i = 0; i < 6; i++)
	{
		widget_convert(widget_conversion_data[i].unpressed_id, widget_conversion_data[i].pressed_id, widget_conversion_data[i].repetitions, widget_conversion_data[i].pixmap_id);
	}
}
