#include <fstream>
#include <iostream>
using namespace std;

const unsigned int MACOS86ROMSIZE = 1945332;
const unsigned int MACOS86ROMCHECKSUM = 0xB93817E7;
const unsigned int MACOS922ROMSIZE = 2796422;
const unsigned int MACOS922ROMCHECKSUM = 0x55DE8BA2;

void usage() {
	cout << "\nUsage:  MacROMChecksum [path to ROM file]\n";
}

int main (int argc, char * const argv[]) {
	// Check if input was usable.
	if (argc != 2) {
		usage();
		return(0);
	}	
	ifstream inFile;
	inFile.open(argv[1]);
	if (!inFile.is_open()) {
		cout << "\nCould not open the specified file.";
		usage();
		return(0);
	}	

	unsigned int sum = 0;
	long unsigned int length = -1;	// -1 is used so that the EOF character is not counted.
	while (!inFile.eof()) {
		inFile.get();
		length++;
	}
	
	// Print out ROM length.
	cout << "\nROM Length: ";
	if (length < 0x100000) cout << length/1024.0 << " kiB\n";
	else  cout << length/1048576.0 << " MiB\n";
	
	// Check if the file size is divisible by 64kiB, which should be true for any ROM.
	if (length == MACOS86ROMSIZE) cout << "This is the file \"Mac OS ROM\" from a Mac OS 8.6 System Folder.\n";
	else if (length == MACOS922ROMSIZE) cout << "This is the file \"Mac OS ROM\" from a Mac OS 9.2.2 System Folder.\n";
	else if (length % 65536 != 0) cout << "The ROM appears to be the wrong length.\n";
	
	// Reset get() function to the beginning of the file.
	inFile.close();
	inFile.open(argv[1]);
	
	// Retrieve the recorded checksum from the ROM.
	unsigned int recorded;
	if (length == MACOS86ROMSIZE) recorded = MACOS86ROMCHECKSUM;
	else if (length == MACOS922ROMSIZE) recorded = MACOS922ROMCHECKSUM;
	else recorded = (inFile.get()<<24)+(inFile.get()<<16)+(inFile.get()<<8)+inFile.get();
	
	// Compute the actual checksum of the ROM.
	if (length != 0x400000) {
		for (long unsigned int i=4; i<length; i+=2) {
			sum += inFile.get()<<8;
			sum += inFile.get();
		}
	}
	// Special case: 4MiB ROMs only checksum the first 3 MiB.
	else {
		for (long unsigned int i=4; i<(length - 0x100000); i+=2) {
			sum += inFile.get()<<8;
			sum += inFile.get();
		}
	}
	
	// Compare computed checksum to recorded checksum, state if this passes or fails.
	if (recorded == sum) cout << "\nROM Checksum PASSED.\n";
	else cout << "\nROM Checksum FAILED.\n";
	
	// Use checksum to determine which Mac it is from.
	cout << "\nThis is a";
	switch (recorded) {
		case 0x28BA61CE:
		case 0x28BA4E50: cout << " Macintosh 128k or 512k"; break;
		case 0x4D1EEEE1:
		case 0x4D1EEAE1:
		case 0x4D1F8172: cout << " Macintosh 512ke or Plus"; break;
		case 0xB2E362A8: cout << " Macintosh SE"; break;
		case 0x9779D2C4:
		case 0x97851DB6: cout << " Macintosh II"; break;
		case 0x97221136: cout << " Macintosh II FDHD, IIx, IIcx, or SE/30"; break;
		case 0xB306E171: cout << " Macintosh SE FDHD"; break;
		case 0x96645F9C: cout << " Macintosh Portable, Backlit Portable, or PowerBook 100"; break;
		case 0x368CADFE: cout << " Macintosh IIci"; break;
		case 0x4147DD77:
		case 0x35C28C8F: cout << " Macintosh IIfx"; break;
		case 0x36B7FB6C: cout << " Macintosh IIsi"; break;
		case 0xA49F9914: cout << " Macintosh Classic"; break;
		case 0x350EACF0: cout << " Macintosh LC"; break;
		case 0x3193670E: cout << " Macintosh Classic II or Performa 200"; break;
		case 0x420DBFF3: cout << " Macintosh Quadra 700 or 900"; break;
		case 0x35C28F5F: cout << " Macintosh LC III, Performa 400, 405, 410 or 430"; break;
		case 0x3DC27823: cout << " Macintosh Quadra 950"; break;
		case 0x49579803: cout << " Macintosh IIvx or Performa 600"; break;
		case 0xE33B2724: cout << " Macintosh PowerBook 160, 165, 165c, 180 or 180c"; break;
		case 0xECFA989B:
		case 0xECFA89A8: cout << " Macintosh PowerBook Duo 230 or 250"; break;
		case 0xECD99DC0: cout << " Macintosh Color Classic or Performa 250"; break;
		case 0xECBBC41C: cout << " Macintosh LC III, III+, 520, Performa 460 or 520"; break;
		case 0xF1A6F343: cout << " Macintosh Centris 610 or Quadra 610"; break;
		case 0xF1ACAD13: cout << " Macintosh Centris 650, Quadra 650 or 800"; break;
		case 0x5BF10FD1: cout << " Macintosh Centris 660AV, Quadra 660AV, 840AV"; break;
		case 0xFF7439EE: cout << " Macintosh LC 475, 575, Performa 475, 476, 575, 577, 578 or Quadra 605"; break;
		case 0x0024D346: cout << " Macintosh PowerBook Duo 270c"; break;
		case 0xEDE66CBD:
		case 0xEAF1678D: cout << " Macintosh Colour Classic II, LC 550, Performa 275, 550, 560 or TV"; break;
		case 0x015621D7: cout << " Macintosh PowerBook Duo 280 or 280c"; break;
		case 0xB6909089: cout << " Macintosh PoweBook 520, 520c, 540 or 540c"; break;
		case 0x06684214: cout << " Macintosh LC 630, Performa 630 or Quadra 630"; break;
		case 0xFDA22562: cout << " Macintosh PowerBook 150"; break;
		case 0x064DC91D: cout << " Macintosh LC 580, Performa 580 or 588"; break;
		case 0x4D27039C: cout << " Macintosh PowerBook 190 or 190cs"; break;
		case 0x9FEB69B3: cout << " Power Macintosh 6100, 7100, 8100"; break;
		case 0x63ABFD3F: cout << " Power Macintosh 5200, 5300, 6200, 6300"; break;
		case 0x6F5724C0: cout << " Power Macintosh 6400 or SuperMac C500"; break;
		case 0x6E92FE08: cout << " Power Macintosh 6500 or 20th Anniversary Mac"; break;
		case 0xED26A1EF: cout << " PowerBook G3 Pismo"; break;
		case 0x09B4DAC4: cout << " Power Macintosh G4 MDD"; break;
		case 0x78F57389: cout << " Power Macintosh G3 Beige"; break;

	// Source 2:  http://mess.redump.net/mess:driver_info:mac_technical_notes
		case 0x78EB4234: cout << " Power Macintosh G3"; break;
		case 0x79E68D63: cout << " Power Macintosh G3 Gossamer"; break;
		case 0xB46FFB63: cout << " PowerBook G3"; break;
		case 0x276EC1F1: cout << " PowerBook 2400, 3400"; break;
		//case 0x6E92FE08: cout << " Power Macintosh 7300, 8600, 9600"; break;
		case 0x83A21950: cout << " PowerBook 1400"; break;
		case 0x83C54F75: cout << " PowerBook 5x0 PPC Upgrade or Duo 2300"; break;
		case 0x96CD923D: cout << " Power Macintosh 7200, 7500, 8500, 9500"; break;
		case 0x852CFBDF: cout << " PowerBook 5300"; break;
		case 0x4957EB49: cout << " Macintosh IIvi"; break;
		case 0x96CA3846: cout << " Macintosh Portable"; break;
	
	// Not actual ROMs, but performs checksum of data fork anyway.  Does not check resource fork.
		case MACOS86ROMCHECKSUM:
		case MACOS922ROMCHECKSUM: cout << " PowerPC Mac OS"; break;
		default: cout << "n unknown";
	}
	cout << " ROM.\n";
	
	return 0;
}